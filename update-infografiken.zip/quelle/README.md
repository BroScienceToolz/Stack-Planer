# Stack-Planer — Quellen und Übergabe

Privates Repo. Hier liegt alles, was man braucht, um das Modell zu verstehen, zu ändern und die drei Artefakte neu zu bauen. Wenn du das hier liest, weil du weitermachen sollst: lies den Abschnitt **Das Modell in fünf Minuten** und dann **Die Fallen**. Der Rest ist Nachschlagewerk.

Kontakt zum Autor: BroScienceToolz@gmail.com

---

## Was hier liegt

| Datei | Rolle |
|---|---|
| `snp_auswertung.py` | **Die Quelle der Wahrheit.** Enthält das komplette Modell (Konstanten, Kategorien, Blutwertbänder), die DNA-Auswertung mit Tkinter-Oberfläche, den Excel-Berichtsbau und die eingebettete SNP-Liste. Rund 6000 Zeilen, davon ~240 KB base64-Blob am Anfang — nicht erschrecken. |
| `SNP_Liste_Roidrelevant_31.xlsx` | 327 SNPs plus die drei Matrix-Blätter (Substanzen × Systeme, Kopplungen, Legende). Beides in einer Mappe, historisch gewachsen. |
| `README-webseite.md` | Das README des **öffentlichen** Repos. Liegt hier, damit beide Texte an einer Stelle gepflegt werden; `repo_bauen.py` kopiert es drüben als `README.md` hin. |
| `sprachen.py` | Alle englischen Entsprechungen für die Webseite. **Nur** für die Webseite — siehe unten. |
| `figuren.py` | Die sieben Infografiken als fertiges CSS und SVG. **Erzeugt**, nicht von Hand geschrieben. |
| `figuren_bauen.py` | Erzeugt `figuren.py` aus `grafiken/`. Muss laufen, wenn eine Grafik dazukommt oder sich ändert. |
| `grafiken/` | Die Originaldateien der Infografiken, so wie sie geliefert wurden. |
| `pfade.py` | Findet die Dateien neben dem Skript. Deshalb laufen alle Skripte sowohl hier flach als auch in der alten Ordnerstruktur mit `tool18/`. |
| `html_bauen.py` | Baut `stack-planer.html` aus dem Modell. Importiert `snp_auswertung.py` und liest die Matrix aus der Mappe. |
| `standalone.py` | Baut `Stack-Planer_standalone.xlsx`, die Excel-Fassung ohne DNA. |
| `liste_neu.py` | **Muss nach jeder Änderung an der Mappe laufen.** Frischt die im Programm eingebettete SNP-Liste auf. |
| `repo_bauen.py` | Packt die beiden GitHub-Ordner (öffentlich/privat). |
| `pruefe_neu.py` | 13 Szenarien: baut Excel-Mappen, lässt sie von LibreOffice durchrechnen, vergleicht gegen eine unabhängige Python-Referenz. |
| `pruefe_html.py` | 12 Szenarien plus Reset-Proben: schneidet das JavaScript aus der fertigen HTML, führt es in Node aus, vergleicht gegen dieselbe Referenz. |
| `EXE_bauen.bat` | Macht unter Windows per Doppelklick eine `.exe` aus `snp_auswertung.py` (PyInstaller). |
| `historie/` | Die Änderungsskripte der letzten Runden. Laufen nicht mehr — ihre Ersetzungen sind längst im Quelltext. Aber jedes trägt im Kopf die **Begründung** für eine Entscheidung, die man dem fertigen Code nicht mehr ansieht. Bevor du etwas rückgängig machst, lies dort nach, warum es so ist. |

Was **nicht** hier liegt, weil es Ballast wäre: die Bearbeitungsskripte für die SNP-Listen-Versionen 11 bis 30. Sie arbeiten auf Mappenversionen, die es nicht mehr gibt, und würden beim ersten Aufruf abstürzen.

---

## Aufsetzen

```bash
pip install openpyxl
```

Das ist alles, was zum Bauen nötig ist. Für die Prüfskripte zusätzlich LibreOffice (`soffice` im Pfad) und Node.

Kompletter Durchlauf nach einer Änderung:

```bash
python3 figuren_bauen.py   # nur wenn sich eine Infografik geändert hat
python3 liste_neu.py       # nur wenn sich die Mappe geändert hat
python3 html_bauen.py      # -> stack-planer.html
python3 standalone.py      # -> Stack-Planer_standalone.xlsx
python3 pruefe_html.py     # muss "stimmen ueberein" sagen
python3 pruefe_neu.py      # dauert ein paar Minuten, muss dasselbe sagen
python3 repo_bauen.py      # packt die GitHub-Ordner
```

Die Reihenfolge ist nicht beliebig. `liste_neu.py` zuerst, sonst baut man aus einer Mappe, die das Programm gar nicht kennt.

---

## Das Modell in fünf Minuten

Alles läuft auf **eine** Zahl hinaus: den Schadensmultiplikator **M**. M sagt, wie viel schneller die Lebensuhr tickt. M = 1 heißt Durchschnitt, M = 2 heißt doppeltes Tempo.

**Schritt 1 — jedes System einzeln.** Es gibt 16 Körpersysteme (`SCHADEN_GEWICHT` im Programm). Jedes bekommt einen Index zwischen 0 (perfekt) und 1 (Anschlag). Der Startwert kommt aus dem Load; wo ein Blutwert eingetragen ist, zählt der zu 75 %, der Bevölkerungsschnitt nur noch zu 25 %.

**Schritt 2 — Nutzen und Last getrennt.** Substanzen wirken nicht auf denselben Kanal. Schaden frisst sich in den *gesunden Rest* und sättigt dabei, Nutzen ist ein Faktor obendrauf:

```
Endindex = (1 − (1 − Index)^(Last^STAPELHEBEL)) × Nutzen
```

Das war eine der wichtigsten Korrekturen überhaupt. Vorher wurde beides multiplikativ verrechnet, und dann klebte das HDL bei Tren plus irgendeinem Oral immer bei 1,000 — Oxandrolon, Turinabol, Stanozolol und Methandienon lieferten alle dasselbe Ergebnis. Das Modell konnte Substanzen nicht mehr auseinanderhalten.

**Schritt 3 — schwächstes Glied.** Aus jedem Endindex wird eine Gefahr:

```
A(i) = ((BEZUGSSCORE/100) / max(INDEX_BODEN, 1 − i))^SCHAERFE
```

Die Kurve zieht nach oben weg. M ist der gewichtete Mittelwert dieser Gefahren. Weil die Kurve konvex ist, kann ein System am Anschlag von fünfzehn gesunden **nicht** aufgewogen werden. Das ist der ganze Sinn der Übung: ein gutes LDL hilft dem Herzmuskel nicht.

**Schritt 4 — Lebensuhr.** Jedes Lebensjahr kostet:

```
f(Alter) = (1 + JAHR_LINEAR·(Alter − BASISALTER)) · JAHR_ZINS^(Alter − BASISALTER)
```

Ein festes `SCHADENSBUDGET` (97,0) wird Jahr für Jahr abgetragen — im Expositionsfenster mit dem Faktor M, sonst mit 1,0. Das Alter, in dem das Budget alle ist, ist das Endalter.

> **Wichtig:** Das Budget muss eine *feste* Zahl bleiben. Es gab eine Fassung, die es aus derselben Kurve ableitete, die es begrenzen sollte — mit dem Ergebnis, dass die Parameter `JAHR_LINEAR` und `JAHR_ZINS` gar nichts mehr taten. Man konnte sie beliebig verstellen, das Endalter rührte sich nicht. Wer hier etwas ändert, prüft danach mit `pruefe_neu.py`, ob eine Parameteränderung überhaupt noch ankommt.

**Klassenlogik.** Innerhalb einer Wirkstoffklasse zählt nur der stärkste Nutzen und die stärkste Last, über Klassen hinweg multiplikativ. Sonst würden ACE-Hemmer und Sartan zusammen doppelt wirken, obwohl das eine die Alternative zum anderen ist.

**Kopplung.** Im Blatt *Medi-Supp-Kopplung* steht je Substanz und System, welcher Messwert die Wirkung steuert und wie viel Restwirkung ohne diesen Messwert bleibt (`LDL:0,10` heißt: 10 % bleiben immer, 90 % hängen am LDL-Band). Ohne das verbesserte ein Statin bei einem LDL von 1,5 den Score trotzdem, weil sein Plaque-Nutzen auf einem anderen System verbucht wird.

---

## Die Blutwertbänder — und warum sie nicht den Leitlinien folgen

Vier Bänder je Wert: gut / leicht daneben / schlecht / **Endlevel**. Das oberste zählt intern als Index 0,0, das Endlevel schaltet die Genetik ab (die Messung zählt zu 100 %) und kostet zusätzlich 4 Punkte.

Daraus folgen zwei Regeln, die bewusst von den Leitlinien abweichen:

**Band 1 ist das Optimum, nicht die Behandlungsschwelle.** Weil Band 1 „hier ist nichts mehr zu holen" bedeutet. Stünde dort die Zahl, ab der ein Arzt einen Kranken behandelt, verschenkte das Modell die ganze Spanne darunter. Dazu kommt der Zeitraum: das Ding rechnet vierzig Jahre nach vorn, Werte wandern nach oben, wer heute auf der Schwelle steht, steht in zehn Jahren darüber.

**Band 4 ist ein Alarm, keine Diagnose.** Ein Endlevel, der erst anschlägt, wenn die Krankheit diagnostizierbar ist, kommt zu spät.

Der aktuelle Stand, jeweils mit der Leitlinienzahl zum Vergleich:

| Wert | gut | Endlevel ab | Leitlinie sagt |
|---|---|---|---|
| Blutdruck syst. | < 115 | 140 | ESC: ab 120 erhöht, ab 140 Hypertonie, 160 Grad 2 |
| Hämatokrit | < 45 | > 54 | Normgrenze Mann 52; Endocrine Society: ab 54 absetzen/Aderlass |
| LDL | < 1,4 (55 mg/dl) | 3,4 (130) | ESC/EAS: 1,4 sehr hohes Risiko, 1,8 hohes, 2,6 mittleres |
| HDL | > 1,3 (50) | < 0,6 (23) | < 1,0 (40) gilt beim Mann als erniedrigt |
| Triglyzeride | < 1,0 (89) | 3,4 (300) | normal < 1,7 (150); Pankreatitis ab 5,6 (500) |
| Glukose nü. | < 80 | 110 | ADA: Prädiabetes 100–125, Diabetes ab 126; WHO IFG ab 110 |
| Cystatin C | < 0,80 (eGFR > 110) | 1,30 (eGFR < 60) | Normbereich bis 1,0; eGFR < 60 = CKD, < 45 = G3b |

Die eGFR-Klammerwerte sind CKD-EPI 2012 für einen 40-jährigen Mann.

---

## Die zweite Sprache — und warum sie nur die Webseite betrifft

Die Webseite ist zweisprachig, die Excel-Mappe und die DNA-Auswertung sind es nicht. Das ist kein Versäumnis, sondern die einzige Trennlinie, die funktioniert: in der Mappe ist jeder Bandtext gleichzeitig eine Vergleichszeichenkette in einer Formel (`IF($C$12="unter 1,4 (55 mg/dl)";…)`). Eine zweite Sprache dort hieße, jede dieser Formeln zu verdoppeln, für einen Nutzen, den ein Werkzeug für den Eigengebrauch nicht hat.

Die Webseite hat das Problem nicht. Sie bekommt beide Texte als Attribute an die Elemente geschrieben — `data-de` und `data-en` — und tauscht sie im Browser aus:

```
<label data-de="LDL-Cholesterin (mmol/l)" data-en="LDL cholesterol (mmol/l)">…
```

Elemente mit `data-html` bekommen ihren Text als `innerHTML`, weil Fettung und Absätze drinstecken; alle anderen als `textContent`. Der **deutsche** Text steht zusätzlich im Element selbst — deshalb zeigt auch eine Vorschau ohne JavaScript etwas Lesbares, und die iOS-Regel weiter unten bleibt intakt.

Was das JavaScript selbst zusammensetzt (der Handlungsplan, die Systemleiste, die Zeile „X % vom Tempo"), holt sich seine Bausteine aus `JS_TEXTE` in `sprachen.py` und die Namen über `tx(objekt, 'name')` aus dem Datenblob, der jeden Namen zweimal trägt: `name` und `nameEn`.

**Die Regel für alles, was neu dazukommt:** trag es in `sprachen.py` nach. Eine neue Substanz, eine neue Kategorie, ein verschobenes Band — `html_bauen.py` prüft beim Bauen jede einzelne Zeichenkette und listet am Ende auf, wofür es keine Entsprechung gefunden hat:

```
OHNE UEBERSETZUNG (2):
   Ezetimib-Kombination
   unter 1,2 (105 mg/dl)
```

Steht dort „Uebersetzung vollstaendig", ist nichts durchgerutscht. Stillschweigend deutsch bleibt kein einziger Text — das war der ganze Sinn der Fehlerliste.

Der Sprachschalter sitzt oben rechts und zeigt immer die Sprache, in die er wechselt. Beim ersten Laden entscheidet `navigator.language`: kein deutscher Browser heißt Englisch. Gespeichert wird die Wahl nicht — die Seite speichert grundsätzlich nichts, und dabei bleibt es.

---

## Die Infografiken

Sieben Grafiken, eine je Blutwert, erreichbar über den Knopf neben dem jeweiligen Auswahlfeld. Sie liegen als reines Inline-SVG in der Seite — kein Bild, keine Schrift von aussen, kein Nachladen. Das war die Bedingung: die Seite macht keinen einzigen Netzwerkaufruf, und dabei bleibt es.

`figuren_bauen.py` holt sie aus `grafiken/` und schreibt `figuren.py`. Drei Dinge passieren dabei, und jedes davon ist nötig:

**Der Stilblock wird eingesperrt.** Alle sieben Originale benutzen dieselben Klassennamen — `.title`, `.axis-line`, `.note` — belegen sie aber unterschiedlich: in der LDL-Grafik ist `.title` 27 Pixel gross, in den anderen 26; `.note` ist dort 12,5 statt 9,5. Einfach zusammengeworfen würde die zuletzt eingebundene Datei alle anderen umschreiben. Jede Grafik bekommt deshalb einen eigenen Rahmenklassennamen (`.ig-LDL`, `.ig-HKT` …), und jede Regel wird darauf eingeschränkt. Das `:root` mit den Farbvariablen wandert auf den Rahmen selbst.

**Die `body`-Regel fliegt raus.** Sie würde sonst die ganze Seite zentrieren und einfärben.

**Die Dunkelmodus-Blöcke fliegen raus.** Der Stack-Planer ist durchgehend hell. Eine Grafik, die bei dunkler Systemeinstellung auf Schwarz umschaltet, säße mitten in einer weissen Seite.

> **Falle, die mich erwischt hat:** das JavaScript setzte beim Umschalten `element.className = 'ig an'` — und warf damit den Rahmenklassennamen weg. Ergebnis: alle Farbvariablen weg, die ganze Grafik pechschwarz. Es muss `classList.add` / `classList.remove` sein. Wer dort etwas ändert, prüft danach im Browser, ob die Kurven noch blau sind.

Die Beschriftungen sind zweisprachig wie der Rest: `figur_svg()` in `html_bauen.py` hängt an jeden `<text>`- und `<tspan>`-Knoten ein `data-de` und `data-en`, und der vorhandene Sprachumschalter erledigt den Rest — SVG-Textknoten können diese Attribute genauso tragen wie alles andere, es brauchte keinen zweiten Mechanismus. Achsenzahlen bleiben unangetastet, Kommazahlen nicht: aus „×1,8" wird „×1.8", genau wie bei den Bändern. `figuren_bauen.py` meldet am Ende, welche Beschriftung noch keine Entsprechung hat.

Die Datei wächst dadurch von 98 auf 265 KB. Das klingt viel, ist es über HTTPS aber nicht: die Pfaddaten der Kurven komprimieren extrem gut, ausgeliefert werden rund 64 KB.

---

## Die Fallen

Jede einzelne davon hat Zeit gekostet. Bitte lesen, bevor du dieselbe Stunde noch mal ausgibst.

**`cell._style` niemals zwischen Mappen kopieren.** Das ist kein Stilobjekt, sondern ein Array von *Indizes* in die Stiltabellen der Quellmappe. Kopiert man es in eine Zielmappe mit anderen Tabellen, verweist die Zelle auf eine Füllung, die es dort nicht gibt — Excel meldet die Datei als beschädigt und „repariert" `/xl/styles.xml`. Richtig ist, die Objekte einzeln zu kopieren: `font`, `fill`, `border`, `alignment`, `protection`, `number_format`. Innerhalb *derselben* Mappe ist `_style` in Ordnung.

**`ws.cell(r, c, None)` löscht nichts.** openpyxl ignoriert ein `None` als Wertargument. Man braucht `ws.cell(r, c).value = None`. Hat damals dazu geführt, dass ein Wert bei Insulin stehenblieb, den ich für gelöscht hielt.

**`insert_cols` verschiebt keine verbundenen Zellen.** Merges muss man von Hand nachziehen.

**`SUMPRODUCT(bereich^exponent)` gibt in LibreOffice still eine 0 zurück**, wenn es nicht als Matrixformel steht. Kein Fehler, keine Warnung, einfach 0. Deshalb rechnet der Planer solche Summen zeilenweise in Hilfszeilen aus.

**`MAXIFS` ist nicht portabel.** Ältere Excel-Versionen und LibreOffice stolpern darüber. Stattdessen `MAX` über eine Hilfszeile.

**Datenvalidierungslisten mit Komma im Text.** Eine Inline-Liste (`formula1="a,b,c"`) wird am Komma zerlegt — deutsche Zahlen wie „unter 1,4" zerfallen dann in zwei Einträge. Der Planer legt die Optionen deshalb in Zellen ab und verweist auf den Bereich. Solange das so bleibt, sind Kommas in Bandtexten unproblematisch.

**Bandtexte sind Vergleichszeichenketten.** Die Excel-Formeln vergleichen den Dropdown-Text wörtlich (`IF($C$12="unter 1,4 (55 mg/dl)",...)`). Wer einen Bandtext ändert, ändert damit Formeln — deshalb steht der Text an genau einer Stelle (`BLUTWERTE` in `snp_auswertung.py`) und alles wird daraus neu erzeugt. Dasselbe gilt für die Namen der Load-Stufen.

**Nach jeder Mappenänderung `liste_neu.py` laufen lassen.** Die SNP-Liste steckt als zlib+base64 im Programm, damit die `.exe` ohne Beilage läuft. Das ist einmal auseinandergelaufen: die Mappe hatte längst Rauchen und Alkohol, das Programm meldete beim Start immer noch 40 Substanzen statt 42. `liste_neu.py` prüft am Ende die Prüfsumme gegen die Mappe — wenn die stimmt, ist alles gut.

**Die iOS-Vorschau führt kein JavaScript aus.** Deshalb sind sämtliche Bedienelemente statisch im HTML und werden von `bau()` nur noch verdrahtet. Wer anfängt, Auswahlfelder per JavaScript zu erzeugen, macht die Seite in Mail, Dateien-App und jedem Messenger wieder unbrauchbar. Aus demselben Grund: kein `Object.values`, kein `Array.includes`, und ein Zweizeiler-Polyfill für `Element.closest`.

**Die Reset-Knöpfe stehen im HTML auf `disabled`** und werden erst von `bau()` freigegeben. Ein Knopf, der ohne JavaScript nichts tut, ist schlimmer als kein Knopf.

**Gewichte mit zehn Nachkommastellen in den JSON-Blob.** Bei sechs weicht die HTML-Fassung in der sechsten Stelle der Punktzahl von der Referenz ab, und `pruefe_html.py` meldet eine Abweichung, die keine ist.

---

## Was bewusst so ist

**Die Load-Staffel 1 / 2,1 / 3 / 5 / 8 ist ausgiebig getestet, ebenso SCHAERFE 1,15.** Nicht aus Versehen „nachjustieren". Wenn du sie änderst, ändert sich die Bedeutung *aller* bisherigen Ergebnisse.

**Steroide werden ohne Ester genannt** — „Trenbolon", nicht „Trenbolonacetat".

**Im DNA-Bericht gibt es keinen Oral-Abzug mehr.** Die 17-alpha-alkylierten Oralen stehen einzeln in der Substanzliste und bringen ihre eigenen Leber-, LDL- und HDL-Faktoren mit. Ein zusätzlicher Pauschalabzug wäre derselbe Schaden zweimal. Was die Leber genetisch von Oralen hält, steht weiterhin als Befund im Bericht — als Text, nicht als zweite Zahl.

**ACE-Hemmer sind nierenprotektiv.** Das wurde im Projekt einmal bestritten; ACE-Hemmer und Sartane haben deshalb bewusst dieselben Nierenwerte bekommen, damit man es bei Bedarf selbst überschreiben kann.

**Alkohol bekommt kein HDL-Plus.** Alkohol hebt das HDL messbar, aber die Mendelsche Randomisierung zeigt, dass dieses HDL nicht schützt. Ein Pluszeichen wäre geschönt.

---

## Offene Punkte

Nichts davon ist kaputt. Es sind die Stellen, an denen ich weitermachen würde.

**Keine Krebskategorie.** Das ist die größte Lücke, und sie ist seit Rauchen und Alkohol größer geworden — bei beiden ist der angesetzte Schaden deshalb eher zu freundlich. Eine Kategorie „Krebsrisiko" mit Gewicht 1,0 wäre die naheliegendste Erweiterung.

**Keine Schlafapnoe.** Hängt direkt am Hämatokrit, am Blutdruck und am Körpergewicht und wäre bei dieser Zielgruppe alles andere als exotisch.

**Auflösung am oberen Ende der Load-Leiter.** Bei Load 8 (1 g) sitzen die dosisempfindlichen Systeme schon bei Index 0,83, bevor überhaupt eine Substanz angehakt ist. Dadurch fallen Unterschiede zwischen Substanzen dort in sich zusammen, und selbst ein Aderlass bei HKT > 55 bringt nur noch +1,4 Punkte. Zwei mögliche Wege: die Leiter oben abflachen, oder die 1 / 2,1 / 3 / 5 / 8 in den Multiplikator schieben statt in den Exponenten. Beides ändert die Kalibrierung, also nicht nebenbei machen.

**Keine untere Grenze beim Hämatokrit.** Unter 38 wird es Blutarmut, das Modell verbucht es als perfekt. Steht als Warnung im Hinweistext, ist aber nicht gerechnet. Dasselbe beim HDL über 2,3 (90 mg/dl), wo die Sterblichkeit wieder ansteigt.

**ASCII-Umlaute in den Bandtexten.** Die Dropdowns schreiben „ueber 54" und „Haematokrit", weil dieselben Zeichenketten in den Excel-Formeln als Vergleichswerte stehen. Echte Umlaute wären machbar, aber Mappe und HTML müssen zusammen umgestellt werden, sonst finden die Formeln ihre Bänder nicht mehr.

---

## Prüfen

Das Modell existiert dreimal unabhängig: als Excel-Formeln, als Python-Referenz in `pruefe_neu.py`, und als JavaScript in der HTML. Alle drei müssen dasselbe rechnen.

- `pruefe_neu.py` baut 13 Szenariomappen, lässt LibreOffice sie durchrechnen und vergleicht Punkte und Endalter auf vier Nachkommastellen gegen die Python-Referenz.
- `pruefe_html.py` schneidet den `<script>`-Block aus der **fertigen** HTML-Datei und führt ihn in Node aus — also genau den Code, der im Browser läuft, keine Abschrift. Dazu 12 Szenarien und fünf Proben auf die Reset-Knöpfe.

Beide müssen „stimmen ueberein" ausgeben. Wenn eines abweicht, ist eine der drei Fassungen beim Ändern vergessen worden — das ist der häufigste Fehler in diesem Projekt und der Grund, warum es die Skripte gibt.

Ein wichtiger Hinweis zum Lesen der Ergebnisse: die Szenarien arbeiten mit Band*nummern*, nicht mit absoluten Messwerten. Wenn du die Bandgrenzen verschiebst, bleiben die Prüfzahlen deshalb gleich — geändert hat sich nur, welcher reale Wert in welchem Band landet. Die Prüfung sagt „die drei Fassungen sind einig", nicht „das Modell ist noch dasselbe".

---

## Disclaimer

Gilt hier genauso wie im öffentlichen Repo: **Keine Therapieempfehlung. Ein Rechenmodell zu Unterhaltungszwecken. Die Einnahme von den aufgeführten Substanzen muss in Absprache mit Ärzten und erfahrenen Coaches erfolgen.**

Die SNP-Liste in diesem Repo ist eine Zusammenstellung aus publizierten Assoziationsstudien. Sie ist kein diagnostisches Panel, und die daraus errechnete „genetische Veranlagung" ist eine Schätzung mit breiter Unsicherheit — nichts, worauf jemand eine Entscheidung über sein Leben stützen sollte.
