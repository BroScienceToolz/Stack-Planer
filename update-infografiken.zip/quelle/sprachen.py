# -*- coding: utf-8 -*-
"""Alle englischen Entsprechungen - nur fuer die HTML-Fassung.

Ab hier trennen sich die Wege: die Excel-Mappe und die DNA-Auswertung bleiben
einsprachig deutsch, weil dort jeder Bandtext gleichzeitig eine
Vergleichszeichenkette in einer Formel ist. Eine zweite Sprache haette dort
jede Formel verdoppelt. Die Webseite dagegen bekommt beide Sprachen als
Attribute an die Elemente geschrieben und schaltet im Browser um.

Deshalb steht hier nur eine Zuordnung deutsch -> englisch. Was in der Matrix
oder im Programm dazukommt, taucht beim naechsten Bau als Fehlmeldung auf und
kann hier nachgetragen werden - html_bauen.py listet am Ende alles auf, wofuer
es keine Uebersetzung gefunden hat. Stillschweigend deutsch bleibt nichts.

Zahlenformat: die deutschen Baender schreiben 1,4 - die englischen 1.4. Das
ist kein Schoenheitsfehler, sondern der Grund, warum die Baender ueberhaupt
einzeln uebersetzt werden und nicht nur die Worte drumherum.
"""

# --------------------------------------------------------------- Auswahlen
LOAD = {
    "Natty oder TRT (400-1000 ng/dl)": "Natural or TRT (400-1000 ng/dl)",
    "TRT plus (1000-1400 ng/dl)": "TRT plus (1000-1400 ng/dl)",
    "Blast moderat (250-350 mg/Woche)": "Blast, moderate (250-350 mg/week)",
    "Blast fortgeschritten (500-750 mg/Woche)": "Blast, advanced (500-750 mg/week)",
    "Blast Profi (1 g und mehr)": "Blast, pro level (1 g and up)",
}
ART = {
    "Dauerblast (durchgehend)": "Permanent blast (no breaks)",
    "Blast and Cruise (Time On = Time Off)": "Blast and cruise (time on = time off)",
}
DAUER = {
    "<5 Jahre": "under 5 years",
    "10 Jahre": "10 years",
    "15 Jahre": "15 years",
    "bis dass der Tod uns scheidet": "till death do us part",
}

# ------------------------------------------------------------- Kategorien
KAT = {
    "Haematokrit/Blutdicke": "Haematocrit / blood thickness",
    "Blutfette-HDL": "Blood lipids - HDL",
    "Blutfette-LDL": "Blood lipids - LDL",
    "Blutdruck/RAAS": "Blood pressure / RAAS",
    "Herzmuskel/Hypertrophie": "Heart muscle / hypertrophy",
    "Gefaesse/Atherosklerose": "Arteries / atherosclerosis",
    "Thrombose/Blutgerinnung": "Thrombosis / clotting",
    "Psyche": "Mental health",
    "Blutfette-TG": "Blood lipids - triglycerides",
    "Herzrhythmus": "Heart rhythm",
    "Gefaesswand/Aorta/Lunge": "Vessel wall / aorta / lungs",
    "Nierenfunktion": "Kidney function",
    "Leber allgemein": "Liver, general",
    "Glukosestoffwechsel": "Glucose metabolism",
    "Blutfette-Lp(a)": "Blood lipids - Lp(a)",
    "Aromatase/E2": "Aromatase / E2",
}
KURZ = {
    "Haematokrit": "Haematocrit", "HDL": "HDL", "LDL": "LDL",
    "Blutdruck": "Blood pressure", "Herzmuskel": "Heart muscle",
    "Gefaesse": "Arteries", "Thrombose": "Thrombosis", "Psyche": "Mental",
    "Triglyzeride": "Triglycerides", "Rhythmus": "Rhythm",
    "Aorta/Lunge": "Aorta/lungs", "Niere": "Kidney", "Leber allg.": "Liver",
    "Glukose": "Glucose", "Lp(a)": "Lp(a)", "E2": "E2",
}

# ---------------------------------------------------------- Wirkstoffklassen
KLASSE = {
    "19-Nor": "19-nor", "5AR-Hemmer": "5-AR inhibitor",
    "ACL-Hemmer": "ACL inhibitor", "Aderlass": "Phlebotomy",
    "Alkohol": "Alcohol", "Aromatasehemmer": "Aromatase inhibitor",
    "Basis": "Base", "Beta-2-Agonist": "Beta-2 agonist",
    "Betablocker": "Beta blocker", "Calciumantagonist": "Calcium blocker",
    "Cholesterin-Resorptionshemmer": "Cholesterol absorption inhibitor",
    "DHT-Derivat": "DHT derivative", "Entkoppler": "Uncoupler",
    "Ernaehrung": "Diet", "Inkretin": "Incretin", "Insulin": "Insulin",
    "Insulinsensitizer": "Insulin sensitiser",
    "Leber-Supplement": "Liver supplement", "Lifestyle": "Lifestyle",
    "OTC-Stack": "OTC stack", "Omega-3": "Omega-3",
    "Oral 17-aa": "Oral 17-aa", "PDE5-Hemmer": "PDE5 inhibitor",
    "Peptidhormon": "Peptide hormone", "Prolaktin": "Prolactin",
    "RAAS-Blocker": "RAAS blocker", "Rauchen": "Smoking", "SARM": "SARM",
    "SERM": "SERM", "SGLT2": "SGLT2",
    "Schilddruesenhormon": "Thyroid hormone", "Sonstige AAS": "Other AAS",
    "Statin/PCSK9": "Statin / PCSK9",
    "Thrombozytenhemmer": "Antiplatelet",
}

# ------------------------------------------------------------- Substanzen
SUB = {
    "Statin": "Statin",
    "Ezetimib": "Ezetimibe",
    "Bempedoinsaeure": "Bempedoic acid",
    "PCSK9-Hemmer oder Inclisiran": "PCSK9 inhibitor or inclisiran",
    "Sartan (ARB)": "Sartan (ARB)",
    "ACE-Hemmer": "ACE inhibitor",
    "Amlodipin (Calciumantagonist)": "Amlodipine (calcium blocker)",
    "Nebivolol (Betablocker)": "Nebivolol (beta blocker)",
    "Tadalafil niedrig dosiert": "Low-dose tadalafil",
    "Blutspende oder Aderlass": "Blood donation or phlebotomy",
    "SGLT2-Hemmer": "SGLT2 inhibitor",
    "GLP-1- oder GLP-1/GIP-Agonist": "GLP-1 or GLP-1/GIP agonist",
    "Berberin oder Metformin": "Berberine or metformin",
    "Omega-3 hochdosiert": "High-dose omega-3",
    "OTC-Stack komplett": "Full OTC stack",
    "Leber-Supplemente (TUDCA, NAC)": "Liver supplements (TUDCA, NAC)",
    "Ausdauertraining und Koerperfett runter":
        "Cardio and lower body fat",
    "Salzreduktion": "Less salt",
    "Aromatasehemmer": "Aromatase inhibitor",
    "5-alpha-Reduktase-Hemmer": "5-alpha-reductase inhibitor",
    "ASS niedrig dosiert": "Low-dose aspirin",
    "Cabergolin oder P5P": "Cabergoline or P5P",
    "SERM (Tamoxifen, Raloxifen, Enclomifen)":
        "SERM (tamoxifen, raloxifene, enclomiphene)",
    "Testosteron": "Testosterone",
    "Nandrolon": "Nandrolone",
    "Trenbolon": "Trenbolone",
    "Boldenon": "Boldenone",
    "Drostanolon": "Drostanolone",
    "Primobolan (Methenolon)": "Primobolan (methenolone)",
    "Oxandrolon": "Oxandrolone",
    "Stanozolol": "Stanozolol",
    "Oxymetholon": "Oxymetholone",
    "Methandienon": "Methandienone",
    "Turinabol": "Turinabol",
    "SARM (RAD-140, LGD-4033, Ostarin)": "SARM (RAD-140, LGD-4033, ostarine)",
    "Wachstumshormon (hGH)": "Growth hormone (hGH)",
    "Insulin": "Insulin",
    "Clenbuterol": "Clenbuterol",
    "T3 (Liothyronin)": "T3 (liothyronine)",
    "DNP": "DNP",
    "Rauchen (10 Zigaretten pro Tag)": "Smoking (10 cigarettes a day)",
    "Alkohol (5 Bier pro Tag)": "Alcohol (5 beers a day)",
}

# ------------------------------------------------------------- Blutwerte
BLUT_NAME = {
    "Blutdruck systolisch": "Blood pressure, systolic",
    "Haematokrit": "Haematocrit",
    "LDL-Cholesterin": "LDL cholesterol",
    "HDL-Cholesterin": "HDL cholesterol",
    "Triglyzeride": "Triglycerides",
    "Nuechternglukose": "Fasting glucose",
    "Cystatin C": "Cystatin C",
}
EINHEIT = {
    "mmHg": "mmHg", "%": "%", "mmol/l": "mmol/l", "mg/dl": "mg/dl",
    "mg/l oder Kreatinin-eGFR": "mg/l or creatinine eGFR",
}
BAND = {
    "nicht gemessen": "not measured",
    # Blutdruck
    "unter 115": "below 115", "115 bis 125": "115 to 125",
    "125 bis 140": "125 to 140", "ab 140": "140 and above",
    # Haematokrit
    "unter 45": "below 45", "45 bis 50": "45 to 50",
    "50 bis 54": "50 to 54", "ueber 54": "above 54",
    # LDL
    "unter 1,4 (55 mg/dl)": "below 1.4 (55 mg/dl)",
    "1,4 bis 2,6 (55-100 mg/dl)": "1.4 to 2.6 (55-100 mg/dl)",
    "2,6 bis 3,4 (100-130 mg/dl)": "2.6 to 3.4 (100-130 mg/dl)",
    "ueber 3,4 (ueber 130 mg/dl)": "above 3.4 (above 130 mg/dl)",
    # HDL
    "ueber 1,3 (50 mg/dl)": "above 1.3 (50 mg/dl)",
    "1,0 bis 1,3 (39-50 mg/dl)": "1.0 to 1.3 (39-50 mg/dl)",
    "0,6 bis 1,0 (23-39 mg/dl)": "0.6 to 1.0 (23-39 mg/dl)",
    "unter 0,6 (unter 23 mg/dl)": "below 0.6 (below 23 mg/dl)",
    # Triglyzeride
    "unter 1,0 (89 mg/dl)": "below 1.0 (89 mg/dl)",
    "1,0 bis 1,7 (89-150 mg/dl)": "1.0 to 1.7 (89-150 mg/dl)",
    "1,7 bis 3,4 (150-300 mg/dl)": "1.7 to 3.4 (150-300 mg/dl)",
    "ueber 3,4 (ueber 300 mg/dl)": "above 3.4 (above 300 mg/dl)",
    # Glukose
    "unter 80 (4,4 mmol/l)": "below 80 (4.4 mmol/l)",
    "80 bis 95 (4,4-5,3 mmol/l)": "80 to 95 (4.4-5.3 mmol/l)",
    "95 bis 110 (5,3-6,1 mmol/l)": "95 to 110 (5.3-6.1 mmol/l)",
    "ab 110 (ab 6,1 mmol/l)": "110 and above (6.1 mmol/l and above)",
    # Cystatin C
    "unter 0,80 (eGFR ueber 110)": "below 0.80 (eGFR above 110)",
    "0,80 bis 1,00 (eGFR 85-110)": "0.80 to 1.00 (eGFR 85-110)",
    "1,00 bis 1,30 (eGFR 60-85)": "1.00 to 1.30 (eGFR 60-85)",
    "ueber 1,30 (eGFR unter 60)": "above 1.30 (eGFR below 60)",
}

HINWEIS = {
 "Blutdruck systolisch":
 "Measured at rest and on several days, not straight after training. Risk "
 "rises continuously from 115/75 mmHg in the large cohorts - there is no "
 "floor below which it stops mattering, which is why the optimum sits below "
 "115. The ESC calls 120 and up elevated and 140 and up hypertension; the "
 "alarm level here starts at 140, because that is where something has to "
 "happen, not at grade 2 (160).",
 "Haematokrit":
 "The value that puts blood donation on the list. 45 and 48 are not the same "
 "thing: blood viscosity climbs disproportionately above roughly 45 per cent, "
 "and even inside the normal range the upper quartiles have more clots and "
 "more cardiac events. That is why the optimum sits below 45 even though 52 "
 "still counts as normal. No doctor would start testosterone therapy above "
 "48, and above 54 the guideline says: cut the dose, stop, or take blood off. "
 "There is a limit at the bottom end too that this model does not know - "
 "below 38 you are anaemic.",
 "LDL-Cholesterin":
 "The optimum is the ESC/EAS target for VERY high risk: below 1.4 mmol/l "
 "(55 mg/dl). That is exactly where a long-term user belongs, and no lower "
 "bound below which things stop improving has ever been found - a newborn "
 "sits at around 30 mg/dl. 1.8 (70 mg/dl) is a treatment threshold for high "
 "risk, not an optimum. The alarm level is 3.4 (130 mg/dl) rather than 4.1 "
 "(160): 160 is the mark for manifest hypercholesterolaemia, and as a warning "
 "that comes too late. This is also where a statin buys the most.",
 "HDL-Cholesterin":
 "CAREFUL, this one runs the other way: high is good. Below 1.0 mmol/l "
 "(40 mg/dl) counts as low in men, but the risk keeps falling up to around "
 "1.5 (60 mg/dl) - which is why the optimum sits above 1.3 (50 mg/dl) rather "
 "than just above the line into pathology. The alarm level is 0.6 (23 mg/dl): "
 "anyone who reaches 0.4 no longer needs a warning. Very high values above "
 "2.3 (90 mg/dl) are not better either, but that is not this group's problem.",
 "Triglyzeride":
 "Measured fasting, otherwise the number is worthless. 1.7 mmol/l (150 mg/dl) "
 "only means 'still normal'; the optimum is below 1.0 (89 mg/dl), and that is "
 "where the people with the best insulin sensitivity sit. The alarm level is "
 "3.4 (300 mg/dl) - the 5.6 (500 mg/dl) at which the pancreas is in danger is "
 "an emergency, and an emergency is no longer a warning.",
 "Nuechternglukose":
 "Fasting means eight hours without food. In the cohorts the risk starts "
 "rising well before 100 mg/dl, so before the official prediabetes line - "
 "which is why the optimum sits below 80. The ADA calls 100 to 125 mg/dl "
 "prediabetes and 126 and above diabetes; the alarm level here is already at "
 "110, where the WHO speaks of impaired fasting glucose. A warning that waits "
 "for the diagnosis is not a warning. Alternatively HbA1c: below 5.0 / 5.0 to "
 "5.4 / 5.4 to 5.8 / 5.8 and above per cent.",
 "Cystatin C":
 "Better than creatinine because it does not depend on muscle mass - in "
 "lifters creatinine reads systematically too high. The bracketed values are "
 "the eGFR by CKD-EPI for a 40-year-old man. The normal range goes up to 1.0, "
 "but mortality and cardiac events already rise inside it, which is why the "
 "optimum sits below 0.80. The alarm level is 1.30, i.e. eGFR 60: that is the "
 "line into chronic kidney disease, not stage G3b. IF YOU HAVE NO CYSTATIN C: "
 "take the eGFR from your creatinine and sort it by the bracketed values - "
 "imprecise beats nothing. With a lot of muscle it comes out systematically "
 "too bad, because creatinine comes from muscle. If it looks bad, have "
 "cystatin C measured before somebody turns your muscle mass into kidney "
 "disease.",
}

# ------------------------------------------------ Oberflaeche und Fliesstext
# Schluessel -> (deutsch, englisch). Der deutsche Text steht so im HTML, der
# englische als Attribut daneben.
UI = {
 "marke": ("Stack-Planer", "Stack Planner"),
 "spr": ("\U0001F1EC\U0001F1E7 English", "\U0001F1E9\U0001F1EA Deutsch"),
 "jetzt": ("jetzt", "now"),
 "nach": ("nach Massnahmen", "after measures"),
 "jahre": ("Jahre", "years"),

 "disclaimer": (
  "Keine Therapieempfehlung. Ein Rechenmodell zu Unterhaltungszwecken. Die "
  "Einnahme von den aufgeführten Substanzen muss in Absprache mit "
  "Ärzten und erfahrenen Coaches erfolgen.",
  "Not medical advice. A calculation model for entertainment. Taking any of "
  "the substances listed here belongs in a conversation with doctors and "
  "experienced coaches."),

 "h1": ("1. Was läuft", "1. What you are running"),
 "h2": ("2. Blutwerte", "2. Blood work"),
 "h3": ("3. Was bringt am meisten", "3. Biggest wins"),
 "h4": ("4. Systeme", "4. Systems"),
 "h5": ("5. Was du nimmst", "5. What you take"),

 "rs_lauf": ("zurücksetzen", "reset"),
 "rs_blut": ("alle auf ungemessen", "all to not measured"),
 "rs_geplant": ("geplant leeren", "clear planned"),
 "rs_alles": ("alles zurücksetzen", "reset everything"),
 "rs_subs": ("alle Häkchen weg", "clear all ticks"),

 "l_load": ("Gesamt-Load", "Total load"),
 "l_art": ("Anwendungsart", "Pattern"),
 "l_dauer": ("Geplante Dauer", "Planned duration"),
 "l_alter": ("Alter", "Age"),

 "hilfe1_t": ("So bedienst du das", "How to use this"),
 "hilfe1": (
  "<p><b>Gesamt-Load:</b> was du an Testosteron und anderen Injizierbaren pro "
  "Woche insgesamt faehrst. Einzelne Stoffe hakst du unten in der Liste "
  "zusaetzlich ab - hier steht nur die Menge.</p>"
  "<p><b>Warum gibt es Luecken bei der Dosierung?</b> Ein Sprung von 449 auf "
  "450 mg macht nichts aus. Dazu kommt, dass Steroide generell plus/minus 20 "
  "Prozent streuen - lass es in einem Labor bestaetigen. Auch die beste "
  "Quelle bekommt mal eine schlechte Charge.</p>"
  "<p><b>Anwendungsart:</b> Blast and Cruise zaehlt nur, wenn die Pause so "
  "lang ist wie der Block und dazwischen echtes TRT laeuft. Alles andere ist "
  "Dauerblast.</p>"
  "<p><b>Geplante Dauer:</b> wie lange du das noch durchziehen willst. Das "
  "aendert die Punktzahl nicht, aber das Endalter - jedes Jahr unter Last "
  "kostet einzeln.</p>"
  "<p><b>Alter:</b> dein heutiges. Ein Jahr unter Last mit 55 kostet mehr als "
  "eines mit 25, und wer aelter anfaengt, hat weniger Rest.</p>"
  "<p>Alles rechnet sich sofort neu, sobald du etwas aenderst.</p>",

  "<p><b>Total load:</b> everything injectable you run per week, testosterone "
  "included, added up. Individual compounds get ticked in the list further "
  "down - this field is only the amount.</p>"
  "<p><b>Why the gaps between the dose steps?</b> Going from 449 to 450 mg "
  "changes nothing. On top of that, gear varies by plus or minus 20 per cent "
  "as a rule - get it lab tested. Even the best source ships a bad batch "
  "sometimes.</p>"
  "<p><b>Pattern:</b> blast and cruise only counts if the break is as long as "
  "the block and there is real TRT in between. Everything else is a permanent "
  "blast.</p>"
  "<p><b>Planned duration:</b> how much longer you intend to keep this up. It "
  "does not change the score, but it changes the final age - every year under "
  "load is paid for separately.</p>"
  "<p><b>Age:</b> yours today. A year under load at 55 costs more than one at "
  "25, and starting later leaves less left over.</p>"
  "<p>Everything recalculates the moment you change something.</p>"),

 "hilfe2_t": ("Warum du hier alles eintragen solltest",
              "Why you should fill in everything here"),
 "hilfe2": (
  "<p><b>Was nicht eingetragen ist, wird geschaetzt.</b> Fuer jeden Wert, der "
  "auf 'nicht gemessen' steht, unterstellt das Modell einen "
  "bevoelkerungstypischen Durchschnitt - also einen Mittelwert, der auf dich "
  "genauso gut oder schlecht passt wie auf jeden anderen. Das ist besser als "
  "nichts, aber es ist geraten.</p>"
  "<p><b>Trag deshalb so viel ein wie du hast, und so genau wie moeglich.</b> "
  "Jeder echte Wert ersetzt eine Schaetzung durch dich.</p>"
  "<p><b>Das oberste Band ist strenger als medizinische Leitlinien.</b> In "
  "der Medizin gelten teilweise hoehere Obergrenzen - aber das sind "
  "Behandlungsempfehlungen fuer kranke Menschen, keine Zielwerte fuer "
  "Menschen, die nicht krank werden wollen. Ein LDL von <3 heisst nicht "
  "gut, es heisst: ab hier bekommt ein Kranker Tabletten. Dieses Modell "
  "rechnet Jahrzehnte nach vorn, und Werte wandern in dieser Zeit nach oben. "
  "Deshalb steht im obersten Band das Optimum und nicht die Schwelle - wer "
  "genau auf der Schwelle steht, steht in zehn Jahren darueber.</p>"
  "<p>Mach das Blutbild morgens, nuechtern. Wenn der Kreatinin-Wert hoch ist, "
  "ist es haeufig eine Fehlinterpretation - bestimme beim naechsten Mal "
  "Cystatin C. Die aufgezeigten Werte sind laengst nicht alles. Lass dich von "
  "deinem Coach oder Arzt beraten.</p>",

  "<p><b>Whatever you leave blank gets guessed.</b> For every value left on "
  "'not measured' the model assumes a population-typical average - a number "
  "that fits you exactly as well or as badly as it fits anyone else. Better "
  "than nothing, but it is a guess.</p>"
  "<p><b>So enter as much as you have, and as precisely as you can.</b> Every "
  "real value replaces a guess about you.</p>"
  "<p><b>The top band is stricter than medical guidelines.</b> Medicine uses "
  "higher limits in places - but those are treatment recommendations for sick "
  "people, not targets for people who would rather not get sick. An LDL under "
  "3 does not mean good, it means: this is where a sick person gets put on "
  "tablets. This model calculates decades ahead, and values drift upwards "
  "over that time. That is why the top band holds the optimum and not the "
  "threshold - anyone sitting exactly on the threshold today is above it in "
  "ten years.</p>"
  "<p>Get your blood drawn in the morning, fasted. A high creatinine reading "
  "is often a misinterpretation - have cystatin C measured next time. The "
  "values listed here are nowhere near everything. Talk to your coach or your "
  "doctor.</p>"),

 "grenzen_t": ("Was die Grenzen bedeuten und woher sie kommen",
               "What the limits mean and where they come from"),
 "hilfe3_t": ("Warum nicht einfach der Durchschnitt?",
              "Why not simply the average?"),
 "hilfe3": (
  "<p>Jedes System wird einzeln bewertet und erst danach zusammengefasst. "
  "Weil die Gefahrenkurve nach oben wegzieht, kann ein System am Anschlag von "
  "keinem gesunden Rest aufgewogen werden – ein gutes LDL hilft dem "
  "Herzmuskel nicht. Die drei schlimmsten stehen rot.</p>",

  "<p>Every system is scored on its own and only then combined. Because the "
  "hazard curve runs away upwards, a system at its limit cannot be offset by "
  "any amount of healthy remainder – a good LDL does not help your "
  "heart muscle. The worst three are shown in red.</p>"),

 "plan_wartet": ("wird berechnet ...", "calculating ..."),
 "suche": ("suchen ...", "search ..."),
 "sub_hilfe": (
  "<b>läuft</b> = nimmst du schon  ·  <b>geplant</b> = "
  "willst du dazunehmen. Die Liste ordnet sich nach dem, was gerade am "
  "meisten brächte.",
  "<b>running</b> = you already take it  ·  <b>planned</b> = "
  "you want to add it. The list sorts itself by what would help most right "
  "now."),
 "nur_schadet": ("Was nur schadet – kein Gesundheitsnutzen",
                 "Pure downside – no health benefit"),
 "tog_l": ("läuft", "running"),
 "tog_g": ("geplant", "planned"),

 "fig_auf": ("Infografik", "Infographic"),
 "fig_zu": ("schließen", "close"),
 "param_t": ("Parameter und Rechenweg", "Parameters and how it calculates"),
 "param_text": (
  "<p>Punkte 80 heisst Durchschnitt und Endalter 88. Jedes System bekommt "
  "einen eigenen Gefahrenfaktor ((1 − Basisindex) / "
  "(1 − Endindex)) hoch Schaerfe; der Mittelwert daraus "
  "laesst die Lebensuhr schneller laufen. Zum Nachstellen sind die Werte hier "
  "fest eingebaut – wer sie aendern will, nimmt die Excel-Mappe.</p>",
  "<p>80 points means average and a final age of 88. Every system gets its "
  "own hazard factor ((1 − base index) / "
  "(1 − final index)) raised to the sharpness; the mean of "
  "those makes the life clock run faster. The values are baked in here "
  "– to change them, use the Excel workbook.</p>"),
 "p_schaerfe": ("Schaerfe", "Sharpness"),
 "p_stapel": ("Stapelhebel", "Stacking leverage"),
 "p_kette": ("Gewicht des schwaechsten Glieds", "Weight of the weakest link"),
 "p_boden": ("Restspielraum bei Index 1", "Remaining headroom at index 1"),
 "p_budget": ("Schadensbudget eines Lebens", "Damage budget of one life"),
 "p_linear": ("Jahresfaktor: linear", "Yearly factor: linear"),
 "p_zins": ("Jahresfaktor: Zinseszins", "Yearly factor: compounding"),
 "p_leb": ("Lebenserwartung ohne Last", "Life expectancy without load"),

 "fuss": (
  "Stack-Planer · Modellstand %(v)s · rechnet vollstaendig im "
  "Browser, es wird nichts gesendet und nichts gespeichert.<br>"
  "Für Fragen und Anregungen: "
  "<a href=\"mailto:BroScienceToolz@gmail.com\">BroScienceToolz@gmail.com</a>",
  "Stack Planner · model version %(v)s · runs entirely in your "
  "browser, nothing is sent anywhere and nothing is stored.<br>"
  "Questions and suggestions: "
  "<a href=\"mailto:BroScienceToolz@gmail.com\">BroScienceToolz@gmail.com</a>"),
}

# ------------------------------- Texte, die das JavaScript selbst zusammenbaut
JS_TEXTE = {
 "de": {"alternative": " · Alternative: ",
        "tempo": " % vom Tempo",
        "gewinn": " Jahre durch die geplanten Massnahmen",
        "leer": "Nichts mehr zu holen – alles Sinnvolle ist angehakt."},
 "en": {"alternative": " · Alternative: ",
        "tempo": " % of the pace",
        "gewinn": " years from the planned measures",
        "leer": "Nothing left to gain – everything sensible is ticked."},
}

# ----------------------------------------------------- Texte in den Grafiken
# Schluessel ist der deutsche Text, wie er in der SVG steht (Entities bereits
# aufgeloest). Was hier fehlt, bleibt stehen wie es ist - Achsenzahlen und
# Einheiten sind in beiden Sprachen gleich. Die Kommazahlen dagegen nicht:
# aus "x1,8" wird "x1.8", genau wie bei den Baendern.
FIG_TEXT = {
 # Einheiten - in beiden Sprachen gleich, stehen hier nur, damit die
 # Vollstaendigkeitspruefung sie nicht als Luecke meldet.
 "mg/dl": "mg/dl", "mg/l": "mg/l",
 # Kopfzeilen
 "LABORWERT · EU-BEVÖLKERUNG, NÜCHTERN":
     "LAB VALUE · EU POPULATION, FASTING",
 "LABORWERT · EU-BEVÖLKERUNG, ERWACHSENE":
     "LAB VALUE · EU POPULATION, ADULTS",
 "LABORWERT · MÄNNER, U-FÖRMIGES RISIKO":
     "LAB VALUE · MEN, U-SHAPED RISK",
 "LABORWERT · MMHG · EU-BEVÖLKERUNG":
     "LAB VALUE · MMHG · EU POPULATION",
 # Titel
 "Blutdruck systolisch": "Blood pressure, systolic",
 "Hämatokrit": "Haematocrit",
 "LDL-Cholesterin": "LDL cholesterol",
 "HDL-Cholesterin": "HDL cholesterol",
 "Triglyceride": "Triglycerides",
 "Nüchternglukose": "Fasting glucose",
 "Cystatin C": "Cystatin C",
 # Median- und Grenzwertfahnen
 "Median 124 mmHg": "Median 124 mmHg",
 "Median 46 %": "Median 46 %",
 "Median 125 mg/dl": "Median 125 mg/dl",
 "Median 52 mg/dl": "Median 52 mg/dl",
 "Median 105 mg/dl": "Median 105 mg/dl",
 "Median 97 mg/dl": "Median 97 mg/dl",
 "Median 0,80 mg/l": "Median 0.80 mg/l",
 "Grenzwert 54 %": "Threshold 54 %",
 # Risikomarken - Komma wird Punkt
 "Referenz ×1,0": "Reference ×1.0",
 "×0,4": "×0.4", "×0,7": "×0.7", "×0,8": "×0.8", "×1,1": "×1.1",
 "×1,2": "×1.2", "×1,3": "×1.3", "×1,7": "×1.7", "×1,8": "×1.8",
 "×2,4": "×2.4", "×2,6": "×2.6", "×4,4": "×4.4", "×6,7": "×6.7",
 "×1,8 (Diabetes)": "×1.8 (diabetes)",
 # Legenden
 "Bevölkerung (EU)": "Population (EU)",
 "Bevölkerung (EU-Erwachsene, Verteilung)":
     "Population (EU adults, distribution)",
 "Bevölkerung (Männer)": "Population (men)",
 "Atherosklerose / KHK": "Atherosclerosis / CHD",
 "Sterblichkeit (Allgemein)": "Mortality (general)",
 "Sterblichkeit (Statin/kontrolliert)": "Mortality (statin / controlled)",
 "Statin / kontrolliert": "Statin / controlled",
 "Allgemeinbevölkerung": "General population",
 "Relatives Risiko – Atherosklerose / KHK":
     "Relative risk – atherosclerosis / CHD",
 "Relatives Risiko – KHK (sinkt mit steigendem HDL)":
     "Relative risk – CHD (falls as HDL rises)",
 "Relatives Sterberisiko (kardiovaskulär)":
     "Relative risk of death (cardiovascular)",
 "Relatives Sterberisiko (steigt mit Cystatin C)":
     "Relative risk of death (rises with cystatin C)",
 "Risiko – Mortalität / Thrombose (U-förmig)":
     "Risk – mortality / thrombosis (U-shaped)",
 "Risiko – Folgeerkrankungen (Diabetes-Schwellenwerte)":
     "Risk – complications (diabetes thresholds)",
 # Fussnoten
 "Kurven unabhängig skaliert – Risikowerte direkt beschriftet (×)":
     "Curves scaled independently – risk values labelled directly (×)",
 "Anstieg beidseitig: Anämie (niedrig) bzw. Polyzythämie (hoch)":
     "Rises at both ends: anaemia (low), polycythaemia (high)",
 # Quellenzeilen
 "Quellen: Verteilung – DEGS1-Studie, RKI Deutschland 2008–2011":
     "Sources: distribution – DEGS1 study, RKI Germany 2008–2011",
 "Risiko – Prospective Studies Collaboration, Lancet 2002":
     "Risk – Prospective Studies Collaboration, Lancet 2002",
 "Quellen: Referenzbereich – DocCheck/Wikipedia (Männer 42–50%)":
     "Sources: reference range – DocCheck/Wikipedia (men 42–50%)",
 "Risiko – Kohortenstudien (U-Form); 54%-Grenze n. Endocrine Society 2018":
     "Risk – cohort studies (U-shape); 54% limit per Endocrine Society 2018",
 "Quellen: Verteilung – Näherung n. europ. Kohorten (DEGS, Lifelines)":
     "Sources: distribution – approx. from EU cohorts (DEGS, Lifelines)",
 "Risiko – Emerging Risk Factors Collaboration, JAMA 2009":
     "Risk – Emerging Risk Factors Collaboration, JAMA 2009",
 "Quellen: Verteilung – Näherung n. europ. Kohorten (Lifelines, DEGS)":
     "Sources: distribution – approx. from EU cohorts (Lifelines, DEGS)",
 "Risiko – Sarwar et al., Circulation 2007 (Näherung)":
     "Risk – Sarwar et al., Circulation 2007 (approx.)",
 "Quellen: Verteilung – Näherung n. EHIS/DEGS (EU-Erwachsene)":
     "Sources: distribution – approx. from EHIS/DEGS (EU adults)",
 "Risiko – ADA/WHO-Diagnosekriterien, illustrative Näherung":
     "Risk – ADA/WHO diagnostic criteria, illustrative approx.",
 "Quellen: Referenzbereich – klinisch-chemische Literatur (Näherung)":
     "Sources: reference range – clinical chemistry literature (approx.)",
 "Risiko – Shlipak et al., NEJM 2005 (Näherung)":
     "Risk – Shlipak et al., NEJM 2005 (approx.)",
 # Der Fliesstext unter der LDL-Grafik. Die Zeilen sind einzeln gesetzt und
 # von Hand umgebrochen - die englischen muessen aehnlich lang bleiben, sonst
 # laufen sie aus der Karte.
 "Schwere Krankheiten wie Krebs senken das LDL.":
     "Serious illness such as cancer lowers LDL.",
 "Daher sieht die Sterblichkeitskurve der Allge-":
     "That makes the mortality curve of the general",
 "meinbevölkerung aus, als wäre niedriges LDL":
     "population look as though low LDL were",
 "schädlich. Auswertungen zu Statin-/PCSK-9-":
     "harmful. Analyses of statin and PCSK9",
 "Therapie zeigen aber: „je niedriger, desto":
     "therapy show the opposite: the lower, the",
 "besser“.": "better.",
}
