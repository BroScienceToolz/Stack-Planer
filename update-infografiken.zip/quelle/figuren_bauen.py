# -*- coding: utf-8 -*-
"""Holt die sieben Infografiken aus den gelieferten Dateien in ein Modul.

Die Grafiken kommen als eigenstaendige HTML-Dateien: ein kleiner Stilblock und
ein reines Inline-SVG, keine Schriften von aussen, kein Skript. Damit lassen
sie sich einbetten, ohne das Versprechen zu brechen, dass die Seite keinen
einzigen Netzwerkaufruf macht.

Drei Dinge muessen dabei passieren:

  1. Der Stilblock wird eingesperrt. Alle sieben Dateien benutzen dieselben
     Klassennamen (.title, .axis-line, .note ...), belegen sie aber
     unterschiedlich: in der LDL-Grafik ist .title 27 Pixel gross, in den
     anderen 26, .note ist dort 12,5 statt 9,5. Zusammengeworfen wuerde die
     letzte Datei alle anderen umschreiben. Jede Grafik bekommt deshalb einen
     eigenen Rahmenklassennamen, und jede Regel wird darauf eingeschraenkt.

  2. Die Regel fuer body faellt weg. Sie wuerde sonst die ganze Seite
     zentrieren und einfaerben.

  3. Die Dunkelmodus-Bloecke fallen weg. Der Stack-Planer ist durchgehend
     hell; eine Grafik, die bei dunkler Systemeinstellung auf Schwarz
     umschaltet, saesse mitten in einer weissen Seite.

Herausgeschrieben wird figuren.py - ein Modul mit fertigem CSS und SVG je
Messwert. Danach braucht der Bau die Originaldateien nicht mehr.
"""
import io, os, re, json

# Kategorie im Modell, Kuerzel fuer den Kapselklassennamen, Dateiname.
QUELLEN = [
    ("Blutdruck/RAAS", "BD", "blutdruck_systolisch.html"),
    ("Haematokrit/Blutdicke", "HK", "haematokrit.html"),
    ("Blutfette-LDL", "LDL", "ldl_kombiniert_v2.html"),
    ("Blutfette-HDL", "HDL", "hdl.html"),
    ("Blutfette-TG", "TG", "triglyceride.html"),
    ("Glukosestoffwechsel", "GLU", "nuechternglukose.html"),
    ("Nierenfunktion", "CYS", "cystatin_c.html"),
]
from pfade import HIER
import os as _os
ORDNER = _os.path.join(HIER, "grafiken")
ZIEL = _os.path.join(HIER, "figuren.py")


def block_weg(css, start):
    """Entfernt einen Block ab der Fundstelle, Klammern mitgezaehlt."""
    i = css.index("{", start)
    tiefe, j = 1, i + 1
    while tiefe:
        if css[j] == "{":
            tiefe += 1
        elif css[j] == "}":
            tiefe -= 1
        j += 1
    return css[:start] + css[j:]


def einsperren(css, rahmen):
    """Jede Regel auf .ig-XXX einschraenken, Dunkelmodus und body entfernen."""
    for muster in (r"@media\s*\(prefers-color-scheme:\s*dark\)",
                   r':root\[data-theme="dark"\]',
                   r"(?m)^\s*body\s*\{"):
        while True:
            t = re.search(muster, css)
            if not t:
                break
            css = block_weg(css, t.start())

    aus = []
    for regel in re.finditer(r"([^{}]+)\{([^{}]*)\}", css):
        sel, inhalt = regel.group(1).strip(), regel.group(2).strip()
        if not sel or not inhalt:
            continue
        neu = []
        for s in sel.split(","):
            s = s.strip()
            if not s:
                continue
            # :root traegt die Farbvariablen - die wandern auf den Rahmen selbst
            neu.append(rahmen if s == ":root" else "%s %s" % (rahmen, s))
        aus.append("%s{%s}" % (",".join(neu), inhalt))
    return "\n".join(aus)


FIG = {}
TEXTE = []
for kat, kuerzel, datei in QUELLEN:
    roh = io.open(os.path.join(ORDNER, datei), encoding="utf-8").read()
    css = re.search(r"<style>(.*?)</style>", roh, re.S).group(1)
    svg = re.search(r"(<svg\b.*?</svg>)", roh, re.S).group(1)
    rahmen = ".ig-" + kuerzel
    FIG[kat] = {"klasse": "ig-" + kuerzel,
                "css": einsperren(css, rahmen),
                "svg": svg}
    # Alle Beschriftungen einsammeln, damit die Uebersetzung vollstaendig wird
    for t in re.finditer(r"<(?:text|tspan)\b[^>]*>([^<]+)</(?:text|tspan)>", svg):
        s = t.group(1).strip()
        if s:
            TEXTE.append(s)

io.open(ZIEL, "w", encoding="utf-8").write(
    "# -*- coding: utf-8 -*-\n"
    '"""Die eingebetteten Infografiken. Erzeugt von figuren_bauen.py.\n\n'
    "Nicht von Hand bearbeiten - wer eine Grafik aendert, legt die neue Datei\n"
    "in den Quellordner und laesst figuren_bauen.py noch einmal laufen.\n"
    '"""\n\nFIGUREN = ' + json.dumps(FIG, ensure_ascii=False, indent=1) + "\n")

print("%d Figuren -> %s (%d KB)" % (len(FIG), ZIEL, os.path.getsize(ZIEL) // 1024))

# Was in den Grafiken steht und keine englische Entsprechung hat. Zahlen und
# Einheiten sind in beiden Sprachen gleich und stehen deshalb zu Recht nicht
# in der Tabelle - alles andere gehoert nachgetragen.
import html as _html
import sprachen
offen = [t for t in sorted(set(TEXTE))
         if _html.unescape(t).strip() not in sprachen.FIG_TEXT
         and not re.match(r"^[\d.,%\s]+$", _html.unescape(t).strip())]
if offen:
    print("OHNE UEBERSETZUNG (%d):" % len(offen))
    for t in offen:
        print("   %s" % _html.unescape(t))
else:
    print("Alle Beschriftungen uebersetzt (%d Stueck, %d verschieden)."
          % (len(TEXTE), len(set(TEXTE))))
