# -*- coding: utf-8 -*-
"""Packt die beiden Ordner, die auf GitHub hochgeladen werden.

Zwei Ordner, weil zwei Repos:

  github/stack-planer/         oeffentlich. Nur das, was ein Fremder benutzen
                               kann: die Webseite, die Excel-Mappe zum
                               Selberrechnen, die Substanzmatrix zum
                               Nachlesen, README und Lizenz.

  github/stack-planer-quelle/  privat. Alles zum Weiterbauen: das
                               Auswertungsprogramm mit der eingebetteten
                               SNP-Liste, die Bauskripte, die Pruefskripte und
                               die Uebergabe fuer den, der weitermacht.

Warum die Trennung nicht sauberer geht: die Webseite wird aus dem
Auswertungsprogramm heraus gebaut - html_bauen.py importiert
snp_auswertung.py, weil dort das Modell steht. Der Generator kann deshalb
nicht ins oeffentliche Repo, ohne das DNA-Tool mitzunehmen. Was oeffentlich
sinnvoll ist, ist das Ergebnis plus die Datengrundlage; wer weiterbauen will,
braucht ohnehin Zugriff auf das private Repo.

Der Aufruf ist immer derselbe:

    python3 html_bauen.py && python3 standalone.py && python3 repo_bauen.py

Die Webseite liegt im oeffentlichen Ordner zweimal: als index.html, damit
GitHub Pages sie unter der nackten Adresse ausliefert, und als
stack-planer.html, weil das der Name ist, unter dem sie herumgereicht wird.
Beide werden hier aus derselben Quelle kopiert, sie koennen also nicht
auseinanderlaufen.
"""
import os, io, shutil, openpyxl
from pfade import HIER, finde

ZIEL = os.path.join(HIER, "github")
OEFF = os.path.join(ZIEL, "stack-planer")
PRIV = os.path.join(ZIEL, "stack-planer-quelle")

for d in (OEFF, PRIV, os.path.join(PRIV, "historie")):
    if os.path.isdir(d):
        shutil.rmtree(d)
    os.makedirs(d)

# ------------------------------------------------------------- oeffentlich
shutil.copy(finde("stack-planer.html"), os.path.join(OEFF, "index.html"))
shutil.copy(finde("stack-planer.html"), os.path.join(OEFF, "stack-planer.html"))
shutil.copy(finde("Stack-Planer_standalone.xlsx"),
            os.path.join(OEFF, "Stack-Planer_standalone.xlsx"))

# Die Substanzmatrix ohne die SNP-Liste: das ist die Datengrundlage des
# Modells, sie enthaelt nichts Genetisches und gehoert damit ins Offene.
wb = openpyxl.load_workbook(finde("SNP_Liste_Roidrelevant_31.xlsx"))
for blatt in list(wb.sheetnames):
    if not blatt.startswith("Medi-Supp"):
        del wb[blatt]
wb.save(os.path.join(OEFF, "Substanz-Matrix.xlsx"))
print("Substanz-Matrix.xlsx: %s" % ", ".join(wb.sheetnames))

# Das oeffentliche README steht hier unter eigenem Namen, damit es nicht mit
# der Uebergabe verwechselt wird - die ist das README DIESES Repos.
shutil.copy(finde("README-webseite.md"), os.path.join(OEFF, "README.md"))
shutil.copy(finde("LICENSE"), os.path.join(OEFF, "LICENSE"))

# ------------------------------------------------------------------ privat
for name in ("snp_auswertung.py", "EXE_bauen.bat",
             "SNP_Liste_Roidrelevant_31.xlsx", "pfade.py", "sprachen.py",
             "figuren.py", "figuren_bauen.py",
             "html_bauen.py",
             "standalone.py", "repo_bauen.py", "liste_neu.py", "pruefe_neu.py",
             "pruefe_html.py", "stack-planer.html",
             "Stack-Planer_standalone.xlsx", "README.md",
             "README-webseite.md", "LICENSE"):
    shutil.copy(finde(name), os.path.join(PRIV, name))

# Die Aenderungsskripte der letzten Runden. Sie laufen nicht mehr - ihre
# Ersetzungen sind laengst drin -, aber jedes traegt im Kopf die Begruendung
# fuer eine Entscheidung, die man dem fertigen Quelltext nicht mehr ansieht.
for f in ("eingebaut.py", "genuss.py", "oral_raus.py", "baender.py",
          "optimum.py", "feinschliff.py", "texte.py"):
    shutil.copy(finde(os.path.join("historie", f)),
                os.path.join(PRIV, "historie", f))

# Die Originaldateien der Infografiken. Ohne sie liesse sich figuren.py nie
# wieder neu erzeugen - und figuren.py ist erzeugt, nicht handgeschrieben.
gz = os.path.join(PRIV, "grafiken")
os.makedirs(gz)
for f in sorted(os.listdir(os.path.join(HIER, "grafiken"))):
    shutil.copy(os.path.join(HIER, "grafiken", f), os.path.join(gz, f))

# Was nicht ins Repo gehoert: Pythons Zwischenspeicher und der Ordner, den
# dieses Skript selbst erzeugt - sonst packt man beim naechsten Mal das
# Ergebnis des letzten Laufs mit ein.
IGNORE = "__pycache__/\n*.pyc\ngithub/\n~$*\n.DS_Store\n"
for d in (OEFF, PRIV):
    io.open(os.path.join(d, ".gitignore"), "w", encoding="utf-8").write(IGNORE)

print("oeffentlich: %s" % ", ".join(sorted(os.listdir(OEFF))))
print("privat:      %s" % ", ".join(sorted(os.listdir(PRIV))))
