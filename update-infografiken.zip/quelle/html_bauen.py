# -*- coding: utf-8 -*-
"""Baut die Standalone-Fassung als eine einzelne HTML-Datei.

Alles kommt aus derselben Quelle wie die Excel-Mappe: Matrix, Kategorien,
Gewichte, Parameter. Wer die Matrix aendert und neu baut, hat es auch hier
drin - die beiden koennen nicht auseinanderlaufen.

Fuers Handy gedacht: eine Spalte, grosse Schaltflaechen, das Ergebnis klebt
oben. Parameter und die langen Erklaerungen stecken in aufklappbaren Kaesten,
damit die Seite nicht zutextet.
"""
import importlib.util, json, io, html
import re
import sprachen, figuren
from pfade import finde

# Alles, wofuer keine englische Entsprechung gefunden wurde. Wird am Ende
# aufgelistet - so faellt jede neue Substanz und jedes neue Band sofort auf,
# statt still auf Deutsch stehen zu bleiben.
FEHLT = []
# Diese Texte enthalten Auszeichnung und muessen als innerHTML gesetzt werden.
HTML_INHALT = {"disclaimer", "sub_hilfe", "fuss"}


def ue(tabelle, wert):
    """Englische Entsprechung, oder der deutsche Text plus Vermerk."""
    if wert in tabelle:
        return tabelle[wert]
    FEHLT.append(wert)
    return wert

TOOL = finde("snp_auswertung.py")
QUELLE = finde("SNP_Liste_Roidrelevant_31.xlsx")
ZIEL = finde("stack-planer.html")
START = 80.0

spec = importlib.util.spec_from_file_location("sa", TOOL)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.MASSNAHMEN = m.lies_matrix(QUELLE)
# Dieselbe Trennung wie im Planer: Substanzen dieser Klassen haben keinen
# Gesundheitsnutzen und stehen unten.
for _s in m.MASSNAHMEN:
    _s["last"] = _s.get("last") or _s["klasse"] in m.LASTKLASSEN

gew = m.schaden_gewichte()
sg = sum(gew.values())
KATS = [k for k, _ in sorted(gew.items(), key=lambda x: (-x[1], x[0]))]
DATEN = {
    # Die Gewichte mit zehn Stellen: bei sechs weicht die HTML-Fassung in der
    # sechsten Nachkommastelle der Punktzahl von der Referenz ab, und dann
    # meldet die Pruefung eine Abweichung, die keine ist.
    "kats": [{"name": k, "nameEn": ue(sprachen.KAT, k),
              "kurz": m.kurz(k), "kurzEn": ue(sprachen.KURZ, m.kurz(k)),
              "w": round(100.0 * gew[k] / sg, 10),
              "sens": m.LOAD_EMPFINDLICH.get(k, 1.0)} for k in KATS],
    "idxBasis": round((100.0 - START) / 100.0, 4),
    "load": [{"t": t, "tEn": ue(sprachen.LOAD, t), "v": v} for t, v in m.LOAD_STUFEN],
    "art": [{"t": t, "tEn": ue(sprachen.ART, t), "v": v} for t, v in m.ART_STUFEN],
    "dauer": [{"t": t, "tEn": ue(sprachen.DAUER, t),
               "j": (j if j is not None else 999)} for t, j in m.DAUER_STUFEN],
    "blut": [{"name": n, "nameEn": ue(sprachen.BLUT_NAME, n), "kat": kat, "code": c,
              "einheit": e, "einheitEn": ue(sprachen.EINHEIT, e), "baender": b,
              "baenderEn": [ue(sprachen.BAND, x) for x in b],
              "hinweis": h, "hinweisEn": ue(sprachen.HINWEIS, n)}
             for n, kat, c, e, b, h in m.BLUTWERTE],
    "messIndex": m.MESS_INDEX,
    "massnahmeStufe": m.MASSNAHME_STUFE,
    # text und zielwert stehen nicht mehr im Blob: sie wurden nie angezeigt und
    # haben die Datei um rund 40 KB aufgeblaeht.
    "subs": [{"name": s["name"], "nameEn": ue(sprachen.SUB, s["name"]),
              "klasse": s["klasse"], "klasseEn": ue(sprachen.KLASSE, s["klasse"]),
              "last": bool(s.get("last")), "evidenz": s.get("evidenz", ""),
              "wirkung": dict((k, v) for k, v in s["wirkung"].items() if k in gew),
              "kopplung": dict((k, [v[0], v[1]]) for k, v in s["kopplung"].items()
                               if k in gew)}
             for s in m.MASSNAHMEN],
    "k": {"bezug": m.BEZUGSSCORE, "iBoden": m.INDEX_BODEN, "schaerfe": m.SCHAERFE,
          "kette": m.KETTENSCHAERFE, "stapel": m.STAPELHEBEL,
          "loadGemessen": m.LOAD_IN_GEMESSEN, "endlevel": m.ENDLEVEL_AUFSCHLAG,
          "budget": m.SCHADENSBUDGET, "basisalter": m.BASISALTER,
          "jahrLinear": m.JAHR_LINEAR, "jahrZins": m.JAHR_ZINS,
          "anfangsalter": m.ANFANGSALTER, "lebenserwartung": m.LEBENSERWARTUNG,
          "uhrEnde": m.UHR_ENDE, "topN": 6},
}
# Die Lastsubstanzen brauchen fuer die Anzeige eine Reihenfolge wie in der Mappe.
DATEN["subs"].sort(key=lambda s: (1 if s["last"] else 0, s["klasse"], s["name"]))

CSS = """
:root{--bg:#f6f7f9;--fg:#1b1f24;--muted:#667085;--linie:#dfe3e8;--karte:#fff;
--blau:#1f4e78;--gruen:#0b7a3b;--gelb:#9c6500;--rot:#b42318;--gelbBg:#fff6da;
--gruenBg:#e6f4ea;--rotBg:#fdecea;--blauBg:#e8f0f7;}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;background:var(--bg);color:var(--fg);
font:15px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
.wrap{max-width:640px;margin:0 auto;padding:0 12px 90px}
header{position:sticky;top:0;z-index:20;background:var(--bg);
padding:8px 0 6px;border-bottom:1px solid var(--linie)}
.ergebnis{display:flex;gap:8px}
.karte{flex:1;border-radius:12px;padding:9px 10px;text-align:center;line-height:1.15}
.karte b{display:block;font-size:26px;font-weight:700}
.karte span{font-size:11px;letter-spacing:.02em;text-transform:uppercase}
.jetzt{background:var(--gelbBg);color:var(--gelb)}
.nach{background:var(--gruenBg);color:var(--gruen)}
.punkte{font-size:11px;color:var(--muted);text-align:center;padding:5px 0 0}
.kopf{display:flex;align-items:center;justify-content:space-between;
padding:0 2px 6px;gap:8px}
.marke{font-size:12px;font-weight:700;color:var(--blau);letter-spacing:.02em}
/* Sprachschalter: zeigt immer die Sprache, in die er wechselt. */
.spr{flex:none;font-family:inherit;font-size:11px;font-weight:600;line-height:1;
color:var(--muted);background:#fff;border:1px solid var(--linie);border-radius:7px;
padding:6px 8px;cursor:pointer;white-space:nowrap}
.spr:disabled{opacity:.4;cursor:default}
h2{font-size:15px;margin:20px 0 8px;color:var(--blau);display:flex;
align-items:center;justify-content:space-between;gap:10px}
/* Zuruecksetzen: klein, grau, rechts in der Ueberschrift. Ohne JavaScript
   bleibt der Knopf ausgegraut - ein toter Knopf ist schlimmer als keiner. */
.rs{flex:none;font-family:inherit;font-size:11px;font-weight:600;line-height:1;
color:var(--muted);background:#fff;border:1px solid var(--linie);border-radius:7px;
padding:7px 9px;cursor:pointer;white-space:nowrap}
.rs:disabled{opacity:.4;cursor:default}
.rs.alles{color:var(--rot);border-color:#f3c0bb}
.box{background:var(--karte);border:1px solid var(--linie);border-radius:12px;
padding:10px 12px;margin-bottom:10px}
label{display:block;font-size:12px;color:var(--muted);margin:8px 0 3px}
select,input[type=number]{width:100%;padding:11px 10px;font-size:16px;
border:1px solid var(--linie);border-radius:9px;background:#fff;color:var(--fg);
appearance:none;-webkit-appearance:none}
.reihe{display:flex;gap:8px}.reihe>*{flex:1;min-width:0}
.plan div{display:flex;justify-content:space-between;gap:10px;align-items:baseline;
padding:9px 10px;border-radius:9px;margin-bottom:5px;background:#f2f4f7}
.plan .top{background:var(--gruenBg)}
.plan .n{font-weight:600;font-size:14px}
.plan .k{display:block;font-weight:400;font-size:11px;color:var(--muted)}
.plan .g{white-space:nowrap;font-weight:700;color:var(--gruen);font-size:13px}
.sys{display:flex;align-items:center;gap:8px;padding:4px 0;font-size:12px}
.sys .nm{width:34%;flex:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.bar{flex:1;height:9px;background:#eceff3;border-radius:5px;overflow:hidden}
.bar i{display:block;height:100%;border-radius:5px}
.sys .v{width:38px;text-align:right;color:var(--muted);flex:none}
.sys.top3 .nm{color:var(--rot);font-weight:700}
.sub{display:flex;align-items:center;gap:8px;padding:7px 0;border-top:1px solid var(--linie)}
.sub:first-child{border-top:none}
.sub .nm{flex:1;min-width:0;font-size:13.5px}
.sub .kl{display:block;font-size:10.5px;color:var(--muted)}
.sub.lastst .nm{color:var(--rot)}
.tog{width:58px;height:32px;flex:none;border:1px solid var(--linie);border-radius:8px;
background:#fff;font-size:11px;color:var(--muted);font-weight:700}
.tog.an{background:var(--blau);border-color:var(--blau);color:#fff}
.tog.an.gp{background:var(--gruen);border-color:var(--gruen)}
.gewinn{width:38px;flex:none;text-align:right;font-size:11.5px;color:var(--gruen);font-weight:700}
.sub.rang{background:var(--gruenBg);border-radius:8px;padding-left:6px;padding-right:6px}
.sub.rang .nm{font-weight:700}
.sub .rz{width:16px;flex:none;font-size:11px;color:var(--gruen);font-weight:700;text-align:center}
.nojs{background:var(--rotBg);border:1px solid #f3c0bb;border-radius:10px;
padding:10px 12px;font-size:12.5px;color:#8a2018;margin:10px 0}
details{margin:8px 0}
summary{cursor:pointer;font-size:12.5px;color:var(--blau);padding:6px 0}
details p{font-size:12.5px;color:var(--muted);margin:5px 0}
.warn{background:var(--gelbBg);border:1px solid #f0d999;border-radius:10px;
padding:9px 11px;font-size:12px;color:#7a5200;margin:10px 0}
.such{width:100%;padding:10px;font-size:14px;border:1px solid var(--linie);
border-radius:9px;margin-bottom:6px}
.pz{display:flex;justify-content:space-between;font-size:12px;padding:5px 0;
border-top:1px solid var(--linie)}
.pz b{font-weight:700}
.glied{font-size:12px;color:var(--rot);font-weight:700;margin-bottom:6px}
.subhilfe{font-size:11.5px;color:var(--muted);margin-bottom:4px}
.nurschaden{font-size:12px;color:var(--rot);font-weight:700;margin:14px 0 2px}
footer{font-size:11px;color:var(--muted);text-align:center;padding:18px 0}
footer a{color:var(--blau)}
/* Beschriftungszeile eines Blutwerts: Name links, Infografik-Knopf rechts. */
.blz{display:flex;align-items:flex-end;justify-content:space-between;gap:8px}
.blz label{flex:1;min-width:0}
.ifb{flex:none;font-family:inherit;font-size:10.5px;font-weight:600;
line-height:1;color:var(--blau);background:var(--blauBg);border:1px solid #cddcea;
border-radius:6px;padding:5px 8px;margin-bottom:3px;cursor:pointer;white-space:nowrap}
.ifb:disabled{opacity:.4;cursor:default}
/* Overlay. Es liegt ueber allem, auch ueber der angehefteten Kopfzeile. */
.ovl{position:fixed;inset:0;z-index:100;background:rgba(20,22,25,.62);
display:flex;align-items:center;justify-content:center;padding:10px}
.ovl[hidden]{display:none}
.ovlin{position:relative;width:100%;max-width:480px;max-height:100%;
overflow:auto;-webkit-overflow-scrolling:touch}
.ovlx{position:absolute;top:6px;right:6px;z-index:2;width:34px;height:34px;
border-radius:17px;border:1px solid var(--linie);background:#fff;color:var(--fg);
font:400 20px/1 inherit;cursor:pointer;padding:0}
.ig{display:none}
.ig.an{display:block}
"""

JS = r"""
// Aeltere Safari-Versionen kennen Element.closest nicht. Ein Zeilen-Notnagel,
// damit das Antippen der Schalter auch dort ankommt.
if(typeof Element!=='undefined'&&!Element.prototype.closest){Element.prototype.closest=function(sel){
  var e=this; while(e&&e.nodeType===1){if(e.matches&&e.matches(sel))return e;
  e=e.parentElement;} return null;};}
const D=DATEN_PLATZHALTER, K=D.k, L=TEXTE_PLATZHALTER;
// Sprache. Der deutsche Text steht fest im HTML, der englische als Attribut
// daneben - deshalb zeigt auch eine Vorschau ohne JavaScript etwas Lesbares.
const SPR={a:'de'};
const tx=(o,f)=>(SPR.a==='en'&&o[f+'En'])?o[f+'En']:o[f];
// Der Auslieferungszustand. Die Reset-Knoepfe stellen genau das wieder her,
// und die Bedienelemente im HTML stehen von Hand auf denselben Werten.
const VORGABE={load:0,art:0,dauer:2,alter:30};
const S={load:VORGABE.load,art:VORGABE.art,dauer:VORGABE.dauer,
         alter:VORGABE.alter,mess:{},laeuft:{},geplant:{}};
const A=i=>Math.pow((K.bezug/100)/Math.max(K.iBoden,1-i),K.schaerfe);
const jf=a=>(1+K.jahrLinear*(a-K.basisalter))*Math.pow(K.jahrZins,a-K.basisalter);
const katVon={}; D.blut.forEach(b=>katVon[b.code]=b.kat);

function rechne(mitGeplant, extra){
  const lf=1+(D.load[S.load].v-1)*D.art[S.art].v;
  let summe=0, endl=0; const teile=[];
  for(const kat of D.kats){
    const mb=S.mess[kat.name];              // Bandindex oder undefined
    let io;
    if(mb!==undefined && mb>=0){
      if(mb===3){io=1; endl++;}
      else{const b=0.75*D.messIndex[mb]+0.25*D.idxBasis;
        io=Math.min(1,1-Math.pow(1-b,1+(lf-1)*kat.sens*K.loadGemessen));}
    }else io=Math.min(1,1-Math.pow(1-D.idxBasis,1+(lf-1)*kat.sens));
    const nut={},las={};
    for(const s of D.subs){
      const an=S.laeuft[s.name], gp=(mitGeplant&&S.geplant[s.name])||(extra===s.name);
      if(!an&&!gp) continue;
      const f=s.wirkung[kat.name]; if(f===undefined) continue;
      if(f<0){las[s.klasse]=Math.min(f,las[s.klasse]===undefined?0:las[s.klasse]);continue;}
      let fk=f;
      if(an && (mb===undefined||mb<0)){ /* laeuft, ungemessen: ungedaempft */ }
      else if(gp){
        const kop=s.kopplung[kat.name];
        if(kop&&kop[1]<1){const mk=katVon[kop[0]], mbb=mk?S.mess[mk]:undefined;
          const st=(mbb!==undefined&&mbb>=0)?D.massnahmeStufe[mbb]:1;
          fk=f*(kop[1]+(1-kop[1])*st);}
      } else continue;
      nut[s.klasse]=Math.max(fk,nut[s.klasse]===undefined?0:nut[s.klasse]);
    }
    let N=1,La=1;
    for(const kl in nut) N*=(1-nut[kl]);
    for(const kl in las) La*=(1-las[kl]);
    const ie=Math.min(1,(1-Math.pow(1-io,Math.pow(La,K.stapel)))*N);
    const t=kat.w/100*Math.pow(A(ie),K.kette);
    summe+=t; teile.push({kat:kat,idx:ie,g:kat.w/100*A(ie)});
  }
  const p=K.endlevel*endl;
  const zu=Math.pow((K.bezug/100)/Math.max(K.iBoden,K.bezug/100-p/100),K.schaerfe);
  const M=Math.pow(summe,1/K.kette)*zu;
  return {M:M, punkte:Math.max(0,Math.min(100,K.bezug/Math.pow(M,1/K.schaerfe))),
          teile:teile};
}
function endalter(M){
  const j=D.dauer[S.dauer].j, a0=S.alter; let kum=0;
  for(let a=K.anfangsalter;a<=K.uhrEnde;a++){
    const v=jf(a)*((a>=a0&&a<a0+j)?M:1);
    if(kum+v>=K.budget) return a+(K.budget-kum)/v;
    kum+=v;
  }
  return K.uhrEnde;
}
// Was jede einzelne Massnahme ZUSAETZLICH zu allem Angehakten braechte.
// Anders als in der Excel-Mappe ist das hier exakt und keine Naeherung: es
// wird schlicht das ganze Modell noch einmal gerechnet.
function gewinne(basis){
  const g={};
  for(const s of D.subs){
    if(s.last||S.laeuft[s.name]||S.geplant[s.name]) continue;
    let nutzt=false; for(const kk in s.wirkung) if(s.wirkung[kk]>0){nutzt=true;break;}
    if(!nutzt) continue;
    g[s.name]=rechne(true,s.name).punkte-basis;
  }
  return g;
}
function plan(gew){
  const roh=[];
  for(const s of D.subs){
    if(gew[s.name]!==undefined&&gew[s.name]>0.05) roh.push({s:s,g:gew[s.name]});
  }
  roh.sort((a,b)=>b.g-a.g);
  const gesehen={}, out=[];
  for(const e of roh){
    if(gesehen[e.s.klasse]!==undefined){
      const o=out[gesehen[e.s.klasse]]; if(!o.alt) o.alt=tx(e.s,'name'); continue;}
    gesehen[e.s.klasse]=out.length;
    out.push({name:tx(e.s,'name'),klasse:tx(e.s,'klasse'),schl:e.s.name,g:e.g});
  }
  return out.slice(0,K.topN);
}
function zeichne(){
  const W=L[SPR.a];
  const jetzt=rechne(false), nach=rechne(true);
  const eJ=endalter(jetzt.M), eN=endalter(nach.M);
  document.getElementById('eJetzt').textContent=Math.round(eJ);
  document.getElementById('eNach').textContent=Math.round(eN);
  document.getElementById('pkt').textContent=
    (eN-eJ>=0.5)?('+'+(eN-eJ).toFixed(1)+W.gewinn):'';
  // Systeme
  const sortiert=jetzt.teile.slice().sort((a,b)=>b.g-a.g);
  const top3=sortiert.slice(0,3).map(t=>t.kat.name);
  const ges=jetzt.teile.reduce((s,t)=>s+t.g,0);
  document.getElementById('sys').innerHTML=jetzt.teile.map(t=>{
    const p=Math.round(100*t.g/ges), rot=top3.indexOf(t.kat.name)>=0;
    const f=t.idx<0.34?'#0b7a3b':t.idx<0.67?'#c58b00':'#b42318';
    return '<div class="sys'+(rot?' top3':'')+'"><span class="nm">'+tx(t.kat,'kurz')+
      '</span><span class="bar"><i style="width:'+Math.round(t.idx*100)+
      '%;background:'+f+'"></i></span><span class="v">'+p+'%</span></div>';}).join('');
  document.getElementById('glied').textContent=tx(sortiert[0].kat,'name')+
    ' – '+Math.round(100*sortiert[0].g/ges)+W.tempo;
  // Plan
  const gew=gewinne(nach.punkte), pl=plan(gew);
  document.getElementById('plan').innerHTML= pl.length? pl.map((e,i)=>
    '<div class="'+(i<3?'top':'')+'"><span class="n">'+(i+1)+'. '+e.name+
    '<span class="k">'+e.klasse+(e.alt?W.alternative+e.alt:'')+'</span></span>'+
    '<span class="g">+'+e.g.toFixed(1)+'</span></div>').join('')
    : '<div><span class="n">'+W.leer+'</span></div>';
  // Gewinn je Substanz
  // Zahl je Substanz, Rangfarbe fuer die ersten drei, und die Liste ordnet
  // sich nach dem, was gerade am meisten braechte.
  const rang={}; pl.slice(0,3).forEach((e,i)=>rang[e.schl]=i+1);
  const box=document.getElementById('schutz');
  const zeilen=[].slice.call(box.children);
  zeilen.forEach(z=>{
    const n=z.getAttribute('data-name'), g=gew[n];
    z.querySelector('.gewinn').textContent=(g!==undefined&&g>0.05)?('+'+g.toFixed(1)):'';
    z.querySelector('.rz').textContent=rang[n]||'';
    z.className='sub'+(rang[n]?' rang':'');
    // aktiv zuerst, dann nach Gewinn, dann der Rest in alter Reihenfolge
    z._s=(S.laeuft[n]||S.geplant[n])?1e6:(g!==undefined?g:-1);
  });
  zeilen.sort((a,b)=>b._s-a._s||a.getAttribute('data-i')-b.getAttribute('data-i'));
  zeilen.forEach(z=>box.appendChild(z));
}
// Sprache umstellen. Jedes Element, das zweisprachig ist, traegt beide Texte
// als Attribut - hier wird nur eingesetzt. Elemente mit data-html bekommen
// ihren Text als innerHTML, weil Fettung und Absaetze drinstecken.
// Infografik zeigen und wieder wegraeumen. Es ist immer genau eine
// sichtbar; geschlossen wird per X, per Tippen auf den Hintergrund und per
// Escape - drei Wege, weil auf dem Handy nur der erste offensichtlich ist.
function figur(kat){
  var f=document.querySelectorAll('.ig'), i;
  for(i=0;i<f.length;i++){
    // classList, NICHT className: der Rahmenklassenname (.ig-LDL) traegt die
    // Farbvariablen der Grafik. Wird er ueberschrieben, ist alles schwarz.
    if(f[i].getAttribute('data-fig')===kat) f[i].classList.add('an');
    else f[i].classList.remove('an');
  }
  document.getElementById('ovl').hidden=false;
}
function figurZu(){ document.getElementById('ovl').hidden=true; }
function setzeSprache(l){
  SPR.a=l;
  document.documentElement.lang=l;
  var e=document.querySelectorAll('[data-de]'), i;
  for(i=0;i<e.length;i++){
    var v=e[i].getAttribute(l==='en'?'data-en':'data-de');
    if(v===null) continue;
    if(e[i].hasAttribute('data-html')) e[i].innerHTML=v;
    else e[i].textContent=v;
  }
  e=document.querySelectorAll('[data-ph-de]');
  for(i=0;i<e.length;i++)
    e[i].placeholder=e[i].getAttribute(l==='en'?'data-ph-en':'data-ph-de');
  e=document.querySelectorAll('[data-al-de]');
  for(i=0;i<e.length;i++)
    e[i].setAttribute('aria-label',
      e[i].getAttribute(l==='en'?'data-al-en':'data-al-de'));
  zeichne();
}
// Zuruecksetzen. Jeder Block raeumt genau das weg, was in ihm steht; 'alles'
// macht die Seite wieder wie frisch geoeffnet. Der Zustand und die
// Bedienelemente werden zusammen gesetzt, damit beide nicht auseinanderlaufen.
function schalter(){
  var t=document.querySelectorAll('.tog');
  for(var i=0;i<t.length;i++){
    var z=t[i].closest('.sub'); if(!z) continue;
    var n=z.getAttribute('data-name');
    var an=(t[i].getAttribute('data-t')==='l')?S.laeuft[n]:S.geplant[n];
    if(an) t[i].classList.add('an'); else t[i].classList.remove('an');
  }
}
function reset(was){
  var i, e;
  if(was==='lauf'||was==='alles'){
    S.load=VORGABE.load; S.art=VORGABE.art;
    S.dauer=VORGABE.dauer; S.alter=VORGABE.alter;
    document.getElementById('load').value=S.load;
    document.getElementById('art').value=S.art;
    document.getElementById('dauer').value=S.dauer;
    document.getElementById('alter').value=S.alter;
  }
  if(was==='blut'||was==='alles'){
    S.mess={};
    e=document.querySelectorAll('[data-blut]');
    for(i=0;i<e.length;i++) e[i].value='-1';
  }
  if(was==='geplant'||was==='alles') S.geplant={};
  if(was==='subs'||was==='alles'){
    S.laeuft={}; S.geplant={};
    var su=document.getElementById('such');
    if(su&&su.value){su.value=''; e=document.querySelectorAll('.sub');
      for(i=0;i<e.length;i++) e[i].style.display='';}
  }
  schalter(); zeichne();
}
function bau(){
  // Die Bedienelemente stehen fest im HTML - hier werden sie nur verdrahtet.
  // Das ist Absicht: wird die Datei in einer Vorschau ohne JavaScript geoeffnet
  // (iPhone, Mail, Dateien-App), sieht man trotzdem alle Auswahlfelder.
  const q=id=>document.getElementById(id);
  S.load=+q('load').value; S.art=+q('art').value;
  S.dauer=+q('dauer').value; S.alter=+q('alter').value;
  var rs=document.querySelectorAll('.rs,.spr,.ifb');
  for(var i=0;i<rs.length;i++) rs[i].disabled=false;
  document.body.addEventListener('click',function(e){
    if(!e.target.closest) return;
    if(e.target.closest('.spr')){setzeSprache(SPR.a==='de'?'en':'de'); return;}
    var ib=e.target.closest('.ifb');
    if(ib){figur(ib.getAttribute('data-fig')); return;}
    // Der Knopf schliesst, und der dunkle Rand auch - aber nicht die Grafik
    // selbst, sonst geht sie beim Scrollen unter dem Finger zu.
    if(e.target.closest('.ovlx')||e.target.id==='ovl'){figurZu(); return;}
    var r=e.target.closest('.rs');
    if(r){reset(r.getAttribute('data-reset')); return;}
    var b=e.target.closest('.tog'); if(!b) return;
    var zeile=b.closest('.sub'); if(!zeile) return;
    var name=zeile.getAttribute('data-name');
    var ziel=b.getAttribute('data-t')==='l'?S.laeuft:S.geplant;
    if(ziel[name]){delete ziel[name];b.classList.remove('an');}
    else{ziel[name]=1;b.classList.add('an');}
    zeichne();
  });
  document.body.addEventListener('change',function(e){
    var t=e.target;
    if(t.id==='load')S.load=+t.value; else if(t.id==='art')S.art=+t.value;
    else if(t.id==='dauer')S.dauer=+t.value;
    else if(t.id==='alter')S.alter=Math.max(18,Math.min(80,+t.value||30));
    else if(t.hasAttribute('data-blut')){
      var k=t.getAttribute('data-blut'), v=+t.value;
      if(v<0) delete S.mess[k]; else S.mess[k]=v;
    } else return;
    zeichne();
  });
  // Die Suche vergleicht gegen den ANGEZEIGTEN Namen, nicht gegen den
  // Schluessel - sonst findet man auf Englisch kein einziges Praeparat.
  q('such').addEventListener('input',function(e){
    var f=e.target.value.toLowerCase(), alle=document.querySelectorAll('.sub');
    for(var i=0;i<alle.length;i++){
      var sn=alle[i].querySelector('.sn');
      var n=(sn?sn.textContent:alle[i].getAttribute('data-name')).toLowerCase();
      alle[i].style.display=n.indexOf(f)>=0?'':'none';
    }
  });
  // Wer keinen deutschen Browser hat, bekommt Englisch - umschalten geht
  // trotzdem jederzeit oben rechts.
  document.addEventListener('keydown',function(e){
    if(e.key==='Escape'||e.keyCode===27) figurZu();
  });
  var bl=(navigator.language||navigator.userLanguage||'de').toLowerCase();
  setzeSprache(bl.indexOf('de')===0?'de':'en');
}
bau();
"""


def zwei(de, en, html_inhalt=False):
    """Beide Sprachen als Attribute. Der deutsche Text steht zusaetzlich im
    Element selbst, damit die Seite ohne JavaScript lesbar bleibt."""
    if en is None:
        FEHLT.append(de)
        en = de
    a = ' data-de="%s" data-en="%s"' % (html.escape(de, True), html.escape(en, True))
    return a + (' data-html' if html_inhalt else "")


def ui(key, html_inhalt=False, **fmt):
    de, en = sprachen.UI[key]
    if fmt:
        de, en = de % fmt, en % fmt
    return zwei(de, en, html_inhalt), de


def kaste(key, offen=False):
    """Aufklappbarer Kasten, Titel und Inhalt beide zweisprachig."""
    at, dt = ui(key + "_t")
    ai, di = ui(key, html_inhalt=True)
    return ('<details%s><summary%s>%s</summary><div%s>%s</div></details>'
            % (" open" if offen else "", at, html.escape(dt), ai, di))


def opts(paare, vorgabe=0):
    return "".join('<option value="%d"%s%s>%s</option>'
                   % (i, " selected" if i == vorgabe else "",
                      zwei(de, en), html.escape(de))
                   for i, (de, en) in enumerate(paare))


def figur_svg(svg):
    """Jede Beschriftung in der Grafik zweisprachig machen.

    Die Umschaltung im Browser sucht nach data-de - SVG-Textknoten koennen das
    genauso tragen wie alles andere, es braucht also keinen zweiten Mechanismus.
    Zahlen und Einheiten bleiben unangetastet: sie sind in beiden Sprachen
    gleich, und jedes zusaetzliche Attribut macht die Datei nur groesser.
    """
    def eins(t):
        auf, inhalt, zu = t.group(1), t.group(2), t.group(3)
        de = html.unescape(inhalt).strip()
        en = sprachen.FIG_TEXT.get(de)
        if en is None or en == de:
            return t.group(0)
        return "%s%s>%s%s" % (auf[:-1], zwei(de, en), inhalt, zu)

    return re.sub(r"(<(?:text|tspan)\b[^>]*>)([^<]+)(</(?:text|tspan)>)",
                  eins, svg)


def figurkasten():
    """Alle sieben Grafiken, verborgen, in einem Overlay."""
    teile = []
    for b in DATEN["blut"]:
        f = figuren.FIGUREN.get(b["kat"])
        if not f:
            continue
        teile.append('<div class="ig %s" data-fig="%s"><div class="card">%s'
                     '</div></div>'
                     % (f["klasse"], html.escape(b["kat"]), figur_svg(f["svg"])))
    de, en = sprachen.UI["fig_zu"]
    return ('<div class="ovl" id="ovl" hidden><div class="ovlin">'
            '<button class="ovlx" type="button" aria-label="%s" '
            'data-al-de="%s" data-al-en="%s">\u00d7</button>%s'
            '</div></div>'
            % (html.escape(de, True), html.escape(de, True),
               html.escape(en, True), "".join(teile)))


def figur_css():
    return "\n".join(f["css"] for f in figuren.FIGUREN.values())


def blutfelder():
    aus = []
    for b in DATEN["blut"]:
        nde = "%s (%s)" % (b["name"], b["einheit"])
        nen = "%s (%s)" % (b["nameEn"], b["einheitEn"])
        felder = [('<option value="-1" selected%s>%s</option>'
                   % (zwei("nicht gemessen", sprachen.BAND.get("nicht gemessen")),
                      "nicht gemessen"))]
        for j, (de, en) in enumerate(zip(b["baender"], b["baenderEn"])):
            felder.append('<option value="%d"%s>%s</option>'
                          % (j, zwei(de, en), html.escape(de)))
        knopf = ""
        if b["kat"] in figuren.FIGUREN:
            a, d = ui("fig_auf")
            knopf = ('<button class="ifb" type="button" disabled data-fig="%s"%s'
                     '>%s</button>' % (html.escape(b["kat"]), a, html.escape(d)))
        aus.append('<div class="blz"><label%s>%s</label>%s</div>'
                   '<select data-blut="%s">%s</select>'
                   % (zwei(nde, nen), html.escape(nde), knopf,
                      html.escape(b["kat"]), "".join(felder)))
    return "".join(aus)


def grenzkasten():
    """Alle sieben Hinweise zugeklappt. Sie erklaeren, warum die Grenzen so
    liegen, wie sie liegen - wichtig genug, um dabei zu sein, aber zu lang,
    um dauerhaft zwischen den Auswahlfeldern zu stehen."""
    zeilen = []
    for b in DATEN["blut"]:
        zeilen.append('<p><b%s>%s</b> <span%s>%s</span></p>'
                      % (zwei(b["name"], b["nameEn"]), html.escape(b["name"]),
                         zwei(b["hinweis"], b["hinweisEn"]),
                         html.escape(b["hinweis"])))
    at, dt = ui("grenzen_t")
    return ('<details><summary%s>%s</summary>%s</details>'
            % (at, html.escape(dt), "".join(zeilen)))


def subzeilen(last):
    aus, i = [], 0
    ev_de, ev_en = " · Evidenz ", " · Evidence "
    for sb in DATEN["subs"]:
        if bool(sb["last"]) != last:
            continue
        kde = sb["klasse"] + (ev_de + sb["evidenz"] if sb["evidenz"] else "")
        ken = sb["klasseEn"] + (ev_en + sb["evidenz"] if sb["evidenz"] else "")
        aus.append(
            '<div class="sub%s" data-name="%s" data-i="%d">'
            '<span class="rz"></span>'
            '<span class="nm"><span class="sn"%s>%s</span>'
            '<span class="kl"%s>%s</span></span>'
            '<span class="gewinn"></span>'
            '<button class="tog" data-t="l"%s>läuft</button>'
            '<button class="tog gp" data-t="g"%s>geplant</button></div>'
            % (" lastst" if last else "", html.escape(sb["name"]), i,
               zwei(sb["name"], sb["nameEn"]), html.escape(sb["name"]),
               zwei(kde, ken), html.escape(kde),
               zwei(*sprachen.UI["tog_l"]), zwei(*sprachen.UI["tog_g"])))
        i += 1
    return "".join(aus)


HTML = """<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Stack-Planer</title>
<style>%(css)s%(figcss)s</style>
<div class="wrap">
<header>
  <div class="kopf">
    <span class="marke"%(a_marke)s>%(marke)s</span>
    <button class="spr" type="button" disabled%(a_spr)s>%(spr)s</button>
  </div>
  <div class="ergebnis">
    <div class="karte jetzt"><span%(a_jetzt)s>%(jetzt)s</span><b><span
      id="eJetzt">&ndash;</span></b><span%(a_jahre)s>%(jahre)s</span></div>
    <div class="karte nach"><span%(a_nach)s>%(nach)s</span><b><span
      id="eNach">&ndash;</span></b><span%(a_jahre)s>%(jahre)s</span></div>
  </div>
  <div class="punkte" id="pkt"></div>
</header>

<noscript><div class="nojs"><b>Diese Vorschau rechnet nicht.</b> Die Seite braucht
JavaScript. Auf dem iPhone oeffnet die Vorschau in Mail oder der Dateien-App kein
JavaScript &ndash; die Datei erst in Safari oeffnen (Teilen &rarr; In Safari oeffnen)
oder auf einen Webspace legen und die Adresse aufrufen.<br><br>
<b>This preview does not calculate.</b> The page needs JavaScript, and the iOS
preview in Mail or Files does not run it. Open the file in Safari instead, or put
it on a web space and call up the address.</div></noscript>

<div class="warn"%(a_disclaimer)s>%(disclaimer)s</div>

<h2><span%(a_h1)s>%(h1)s</span><button class="rs" data-reset="lauf" disabled
    type="button"%(a_rs_lauf)s>%(rs_lauf)s</button></h2>
<div class="box">
  <label%(a_l_load)s>%(l_load)s</label><select id="load">%(load)s</select>
  <label%(a_l_art)s>%(l_art)s</label><select id="art">%(art)s</select>
  <div class="reihe">
    <div><label%(a_l_dauer)s>%(l_dauer)s</label><select id="dauer">%(dauer)s</select></div>
    <div><label%(a_l_alter)s>%(l_alter)s</label><input type="number" id="alter"
         min="18" max="80" value="30" inputmode="numeric"></div>
  </div>
  %(hilfe1)s
</div>

<h2><span%(a_h2)s>%(h2)s</span><button class="rs" data-reset="blut" disabled
    type="button"%(a_rs_blut)s>%(rs_blut)s</button></h2>
<div class="box">
  %(blut)s
  %(grenzen)s
  %(hilfe2)s
</div>

<h2><span%(a_h3)s>%(h3)s</span><button class="rs" data-reset="geplant"
    disabled type="button"%(a_rs_geplant)s>%(rs_geplant)s</button></h2>
<div class="box plan" id="plan"><div><span class="n"%(a_plan_wartet)s
  >%(plan_wartet)s</span></div></div>

<h2><span%(a_h4)s>%(h4)s</span><button class="rs alles" data-reset="alles" disabled
    type="button"%(a_rs_alles)s>%(rs_alles)s</button></h2>
<div class="box">
  <div class="glied" id="glied"></div>
  <div id="sys"></div>
  %(hilfe3)s
</div>

<h2><span%(a_h5)s>%(h5)s</span><button class="rs" data-reset="subs" disabled
    type="button"%(a_rs_subs)s>%(rs_subs)s</button></h2>
<div class="box">
  <input class="such" id="such" autocomplete="off" placeholder="%(suche)s"
         data-ph-de="%(suche)s" data-ph-en="%(suche_en)s">
  <div class="subhilfe"%(a_sub_hilfe)s>%(sub_hilfe)s</div>
  <div id="schutz">%(schutz)s</div>
  <div class="nurschaden"%(a_nur_schadet)s>%(nur_schadet)s</div>
  <div id="last">%(last)s</div>
</div>

%(param)s

<footer%(a_fuss)s>%(fuss)s</footer>
</div>
%(figuren)s
<script>%(js)s</script>
"""

# ------------------------------------------------------------- Parameterkasten
zeilen = []
for t, v in m.LOAD_STUFEN:
    zeilen.append('<div class="pz"><span%s>%s</span><b>%.2f</b></div>'
                  % (zwei(t, sprachen.LOAD.get(t)), html.escape(t), v))
for key, wert in (("p_schaerfe", m.SCHAERFE), ("p_stapel", m.STAPELHEBEL),
                  ("p_kette", m.KETTENSCHAERFE), ("p_boden", m.INDEX_BODEN),
                  ("p_budget", m.SCHADENSBUDGET), ("p_linear", m.JAHR_LINEAR),
                  ("p_zins", m.JAHR_ZINS), ("p_leb", m.LEBENSERWARTUNG)):
    a, d = ui(key)
    zeilen.append('<div class="pz"><span%s>%s</span><b>%s</b></div>'
                  % (a, html.escape(d), wert))
at, dt = ui("param_t")
ai, di = ui("param_text", html_inhalt=True)
param = ('<details><summary%s>%s</summary><div%s>%s</div>%s</details>'
         % (at, html.escape(dt), ai, di, "".join(zeilen)))

# ------------------------------------------------------------------ Schreiben
felder = {"css": CSS, "hilfe1": kaste("hilfe1"), "hilfe2": kaste("hilfe2"),
          "hilfe3": kaste("hilfe3"), "param": param, "grenzen": grenzkasten(),
          "load": opts([(o["t"], o["tEn"]) for o in DATEN["load"]]),
          "art": opts([(o["t"], o["tEn"]) for o in DATEN["art"]]),
          "dauer": opts([(o["t"], o["tEn"]) for o in DATEN["dauer"]], 2),
          "blut": blutfelder(), "schutz": subzeilen(False),
          "figuren": figurkasten(), "figcss": figur_css(),
          "last": subzeilen(True),
          "suche": html.escape(sprachen.UI["suche"][0], True),
          "suche_en": html.escape(sprachen.UI["suche"][1], True)}
for key in ("marke", "spr", "jetzt", "nach", "jahre", "disclaimer",
            "h1", "h2", "h3", "h4", "h5", "rs_lauf", "rs_blut", "rs_geplant",
            "rs_alles", "rs_subs", "l_load", "l_art", "l_dauer", "l_alter",
            "plan_wartet", "sub_hilfe", "nur_schadet"):
    felder["a_" + key], felder[key] = ui(key, html_inhalt=key in HTML_INHALT)
felder["a_fuss"], felder["fuss"] = ui("fuss", html_inhalt=True, v=m.VERSION)
felder["js"] = (JS.replace("DATEN_PLATZHALTER",
                           json.dumps(DATEN, ensure_ascii=False))
                  .replace("TEXTE_PLATZHALTER",
                           json.dumps(sprachen.JS_TEXTE, ensure_ascii=False)))

io.open(ZIEL, "w", encoding="utf-8").write(HTML % felder)
print("-> %s  (%d KB)" % (ZIEL, len(io.open(ZIEL, encoding="utf-8").read()) // 1024))
if FEHLT:
    print("OHNE UEBERSETZUNG (%d):" % len(FEHLT))
    for f in sorted(set(FEHLT)):
        print("   %s" % f)
else:
    print("Uebersetzung vollstaendig.")
